"""History compaction and context-caching configuration for ADK conversations.

Combines two complementary mechanisms to prevent context bloat:
1. Native Google ADK ``EventsCompactionConfig`` (using ``LlmEventSummarizer``
   backed by Gemini Flash) plus ``ContextCacheConfig`` on the ADK ``App``.
2. Deterministic token-budget sliding-window ``ContextCompactor`` that compacts
   oversized conversation histories, redacts PII prior to summarization, and
   can trim ``LlmRequest.contents`` inside a ``before_model_callback``.
"""

from __future__ import annotations

import math
from typing import Any

from google.adk.agents.context_cache_config import ContextCacheConfig
from google.adk.apps.app import EventsCompactionConfig
from google.adk.apps.llm_event_summarizer import LlmEventSummarizer
from google.adk.models.google_llm import Gemini
from google.adk.models.llm_request import LlmRequest
from google.genai import types
from pydantic import BaseModel, ConfigDict, Field

from agent_app.observability.logging_config import get_logger
from agent_app.observability.pii_redactor import PIIRedactor, get_default_redactor
from agent_app.observability.tracing import traced_operation


def estimate_token_count(text: str) -> int:
    """Estimates token count using a conservative 4-characters-per-token heuristic."""
    if not text:
        return 0
    return max(1, math.ceil(len(text) / 4))


class CompactionResult(BaseModel):
    """Structured telemetry describing the effect of a history compaction pass."""

    model_config = ConfigDict(extra="forbid")

    compacted: bool
    original_turn_count: int = Field(..., ge=0)
    resulting_turn_count: int = Field(..., ge=0)
    original_tokens: int = Field(..., ge=0)
    resulting_tokens: int = Field(..., ge=0)
    tokens_saved: int
    summary_text: str | None = None
    turns: list[dict[str, str]] = Field(default_factory=list)


class ContextCompactor:
    """Token-budget sliding-window & summarization compactor with PII scrubbing."""

    def __init__(
        self,
        *,
        max_token_budget: int = 4000,
        recent_turns_to_keep: int = 4,
        summary_max_chars: int = 800,
        redactor: PIIRedactor | None = None,
    ) -> None:
        if max_token_budget < 64:
            raise ValueError("max_token_budget must be at least 64 tokens.")
        if recent_turns_to_keep < 1:
            raise ValueError("recent_turns_to_keep must be at least 1.")
        self.max_token_budget = max_token_budget
        self.recent_turns_to_keep = recent_turns_to_keep
        self.summary_max_chars = summary_max_chars
        self.redactor = redactor or get_default_redactor()
        self.logger = get_logger("geap.memory.compaction")

    def _summarize_older_turns(self, older_turns: list[dict[str, str]]) -> str:
        """Condenses older turns into a compact, PII-scrubbed digest."""
        bullets: list[str] = []
        for idx, turn in enumerate(older_turns, start=1):
            role = turn.get("role", "user")
            raw_content = str(turn.get("content", "")).strip()
            clean_content = self.redactor.redact_text(raw_content)
            snippet = clean_content[:140].replace("\n", " ")
            if len(clean_content) > 140:
                snippet += "..."
            bullets.append(f"[{idx}:{role}] {snippet}")

        header = (
            f"Compacted conversation summary ({len(older_turns)} earlier turns): "
        )
        body = " | ".join(bullets)
        combined = header + body
        if len(combined) > self.summary_max_chars:
            combined = combined[: self.summary_max_chars - 3].rstrip() + "..."
        return combined

    def compact_history(self, turns: list[dict[str, str]]) -> CompactionResult:
        """Compacts conversation turns whenever total tokens exceed ``max_token_budget``.

        Preserves any pinned ``system`` messages and the latest
        ``recent_turns_to_keep`` conversational turns, replacing older turns
        with a single PII-scrubbed summary message.
        """
        with traced_operation(
            "memory.compact_history",
            attributes={
                "compaction.turn_count": len(turns),
                "compaction.max_token_budget": self.max_token_budget,
            },
        ) as span:
            original_tokens = sum(
                estimate_token_count(str(t.get("content", ""))) for t in turns
            )

            pinned_system = [t for t in turns if t.get("role") == "system"]
            conversational = [t for t in turns if t.get("role") != "system"]

            if (
                original_tokens <= self.max_token_budget
                or len(conversational) <= self.recent_turns_to_keep
            ):
                span.set_attribute("compaction.triggered", False)
                return CompactionResult(
                    compacted=False,
                    original_turn_count=len(turns),
                    resulting_turn_count=len(turns),
                    original_tokens=original_tokens,
                    resulting_tokens=original_tokens,
                    tokens_saved=0,
                    summary_text=None,
                    turns=list(turns),
                )

            older = conversational[: -self.recent_turns_to_keep]
            recent = conversational[-self.recent_turns_to_keep :]
            summary_text = self._summarize_older_turns(older)

            compacted_turns: list[dict[str, str]] = [
                *pinned_system,
                {"role": "assistant", "content": summary_text},
                *recent,
            ]
            resulting_tokens = sum(
                estimate_token_count(str(t.get("content", ""))) for t in compacted_turns
            )
            tokens_saved = original_tokens - resulting_tokens

            span.set_attribute("compaction.triggered", True)
            span.set_attribute("compaction.tokens_saved", tokens_saved)
            self.logger.info(
                "context.compaction.completed",
                original_turns=len(turns),
                resulting_turns=len(compacted_turns),
                original_tokens=original_tokens,
                resulting_tokens=resulting_tokens,
                tokens_saved=tokens_saved,
            )
            return CompactionResult(
                compacted=True,
                original_turn_count=len(turns),
                resulting_turn_count=len(compacted_turns),
                original_tokens=original_tokens,
                resulting_tokens=resulting_tokens,
                tokens_saved=tokens_saved,
                summary_text=summary_text,
                turns=compacted_turns,
            )

    def compact_llm_request(self, llm_request: LlmRequest) -> CompactionResult:
        """Applies sliding-window compaction directly to an ADK ``LlmRequest``."""
        contents = list(llm_request.contents or [])
        turns: list[dict[str, str]] = []
        for content in contents:
            text_parts = [
                getattr(part, "text", "")
                for part in (content.parts or [])
                if getattr(part, "text", None)
            ]
            turns.append(
                {
                    "role": content.role or "user",
                    "content": "\n".join(text_parts),
                }
            )

        result = self.compact_history(turns)
        if result.compacted and result.summary_text:
            retained_contents = contents[-self.recent_turns_to_keep :]
            summary_content = types.Content(
                role="model",
                parts=[types.Part.from_text(text=result.summary_text)],
            )
            llm_request.contents = [summary_content, *retained_contents]
        return result


def build_adk_compaction_config(
    *,
    flash_model: str = "gemini-2.5-flash",
    compaction_interval: int = 5,
    overlap_size: int = 1,
    token_threshold: int = 4000,
    event_retention_size: int = 2,
) -> EventsCompactionConfig:
    """Constructs native ADK ``EventsCompactionConfig`` using a Flash summarizer."""
    summarizer = LlmEventSummarizer(
        llm=Gemini(model=flash_model),
        prompt_template=(
            "Summarize the following Enterprise SRE conversation events concisely. "
            "Preserve service names, incident ticket IDs, metrics, runbook IDs, and "
            "pending human approval IDs. Exclude any PII or secrets:\n\n{conversation_history}"
        ),
    )
    return EventsCompactionConfig(
        summarizer=summarizer,
        compaction_interval=compaction_interval,
        overlap_size=overlap_size,
        token_threshold=token_threshold,
        event_retention_size=event_retention_size,
    )


def build_context_cache_config(
    *,
    min_tokens: int = 1024,
    ttl_seconds: int = 600,
    cache_intervals: int = 5,
) -> ContextCacheConfig:
    """Constructs native ADK ``ContextCacheConfig`` for Google Cloud context caching."""
    return ContextCacheConfig(
        min_tokens=min_tokens,
        ttl_seconds=ttl_seconds,
        cache_intervals=cache_intervals,
    )


def extract_text_from_contents(contents: list[Any] | None) -> str:
    """Helper extracting concatenated plain text from ADK ``types.Content`` items."""
    parts_text: list[str] = []
    for content in contents or []:
        for part in getattr(content, "parts", None) or []:
            text = getattr(part, "text", None)
            if text:
                parts_text.append(text)
    return "\n".join(parts_text)
