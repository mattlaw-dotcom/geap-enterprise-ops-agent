"""Asynchronous memory consolidation and persistent long-term memory service.

Ensures expensive memory extraction, PII scrubbing, deduplication, and
persistence execute in non-blocking ``asyncio.create_task`` background workers
so interactive agent turns never block on memory bank writes.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import sqlite3
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from google.adk.memory.base_memory_service import BaseMemoryService, SearchMemoryResponse
from google.adk.memory.memory_entry import MemoryEntry
from google.adk.memory.vertex_ai_memory_bank_service import VertexAiMemoryBankService
from google.adk.sessions.session import Session
from google.genai import types

from agent_app.config.secrets import AppSettings, get_settings
from agent_app.observability.logging_config import get_logger
from agent_app.observability.pii_redactor import PIIRedactor, get_default_redactor
from agent_app.observability.tracing import traced_operation


@dataclass
class ConsolidatedMemoryRecord:
    """A PII-scrubbed, deduplicated operational memory entry."""

    memory_id: str
    app_name: str
    user_id: str
    session_id: str
    summary: str
    content_hash: str
    tags: list[str] = field(default_factory=list)
    created_at_utc: str = ""


class PersistentSQLiteMemoryService(BaseMemoryService):
    """Persistent SQLite implementation of ADK ``BaseMemoryService`` with PII redaction."""

    def __init__(
        self,
        db_path: str | Path | None = None,
        *,
        redactor: PIIRedactor | None = None,
    ) -> None:
        resolved = Path(db_path or get_settings().memory_db_path).expanduser()
        resolved.parent.mkdir(parents=True, exist_ok=True)
        self.db_path = str(resolved)
        self.redactor = redactor or get_default_redactor()
        self.logger = get_logger("geap.memory.service")
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_schema(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS long_term_memories (
                    memory_id TEXT PRIMARY KEY,
                    app_name TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    session_id TEXT NOT NULL,
                    author TEXT NOT NULL,
                    content_text TEXT NOT NULL,
                    content_hash TEXT NOT NULL,
                    metadata_json TEXT NOT NULL,
                    created_at_utc TEXT NOT NULL,
                    UNIQUE(app_name, user_id, content_hash)
                )
                """
            )

    def _store_text_sync(
        self,
        *,
        app_name: str,
        user_id: str,
        session_id: str,
        author: str,
        raw_text: str,
        metadata: dict[str, Any] | None = None,
    ) -> ConsolidatedMemoryRecord | None:
        scrubbed_text = self.redactor.redact_text(raw_text).strip()
        if not scrubbed_text:
            return None
        content_hash = hashlib.sha256(scrubbed_text.encode("utf-8")).hexdigest()
        memory_id = f"mem-{uuid.uuid4().hex[:12]}"
        created_at = datetime.now(timezone.utc).isoformat()
        clean_metadata = self.redactor.redact_payload(metadata or {})

        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO long_term_memories (
                    memory_id, app_name, user_id, session_id, author,
                    content_text, content_hash, metadata_json, created_at_utc
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    memory_id,
                    app_name,
                    user_id,
                    session_id,
                    author,
                    scrubbed_text,
                    content_hash,
                    json.dumps(clean_metadata, sort_keys=True),
                    created_at,
                ),
            )
        return ConsolidatedMemoryRecord(
            memory_id=memory_id,
            app_name=app_name,
            user_id=user_id,
            session_id=session_id,
            summary=scrubbed_text,
            content_hash=content_hash,
            tags=list(clean_metadata.get("tags", [])),
            created_at_utc=created_at,
        )

    async def add_session_to_memory(self, session: Session) -> None:
        """Extracts and persists PII-scrubbed session events asynchronously."""
        extracted_lines: list[str] = []
        for event in session.events or []:
            content = getattr(event, "content", None)
            if content and getattr(content, "parts", None):
                for part in content.parts:
                    text = getattr(part, "text", None)
                    if text:
                        extracted_lines.append(f"[{event.author}] {text}")
        if not extracted_lines and session.state:
            extracted_lines.append(json.dumps(dict(session.state), default=str))

        combined = "\n".join(extracted_lines)
        await asyncio.to_thread(
            self._store_text_sync,
            app_name=session.app_name,
            user_id=session.user_id,
            session_id=session.id,
            author="session_consolidator",
            raw_text=combined,
            metadata={"event_count": len(session.events or [])},
        )

    async def store_consolidated_fact(
        self,
        *,
        app_name: str,
        user_id: str,
        session_id: str,
        fact_text: str,
        tags: list[str] | None = None,
    ) -> ConsolidatedMemoryRecord | None:
        """Stores a single consolidated operational fact without blocking the event loop."""
        return await asyncio.to_thread(
            self._store_text_sync,
            app_name=app_name,
            user_id=user_id,
            session_id=session_id,
            author="async_consolidator",
            raw_text=fact_text,
            metadata={"tags": tags or []},
        )

    def _search_sync(self, *, app_name: str, user_id: str, query: str) -> list[MemoryEntry]:
        terms = [t.lower() for t in query.split() if len(t) >= 2]
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT * FROM long_term_memories
                WHERE app_name = ? AND user_id = ?
                ORDER BY created_at_utc DESC
                LIMIT 50
                """,
                (app_name, user_id),
            ).fetchall()

        scored: list[tuple[int, sqlite3.Row]] = []
        for row in rows:
            haystack = f"{row['content_text']} {row['metadata_json']}".lower()
            hits = sum(1 for term in terms if term in haystack)
            if hits > 0 or not terms:
                scored.append((hits, row))

        scored.sort(key=lambda item: item[0], reverse=True)
        entries: list[MemoryEntry] = []
        for _, row in scored[:10]:
            entries.append(
                MemoryEntry(
                    id=row["memory_id"],
                    author=row["author"],
                    timestamp=row["created_at_utc"],
                    custom_metadata=json.loads(row["metadata_json"]),
                    content=types.Content(
                        role="model",
                        parts=[types.Part.from_text(text=row["content_text"])],
                    ),
                )
            )
        return entries

    async def search_memory(
        self, *, app_name: str, user_id: str, query: str
    ) -> SearchMemoryResponse:
        """Searches persistent memories asynchronously using keyword overlap ranking."""
        entries = await asyncio.to_thread(
            self._search_sync, app_name=app_name, user_id=user_id, query=query
        )
        return SearchMemoryResponse(memories=entries)


class AsyncMemoryConsolidator:
    """Schedules non-blocking background memory consolidation tasks via ``asyncio``."""

    def __init__(
        self,
        memory_service: BaseMemoryService,
        *,
        redactor: PIIRedactor | None = None,
    ) -> None:
        self.memory_service = memory_service
        self.redactor = redactor or get_default_redactor()
        self.logger = get_logger("geap.memory.async_consolidator")
        self._tasks: set[asyncio.Task[Any]] = set()
        self.completed_count: int = 0
        self.failed_count: int = 0

    @property
    def pending_count(self) -> int:
        return len(self._tasks)

    def schedule_session_consolidation(self, session: Session) -> asyncio.Task[None]:
        """Launches a fire-and-forget background task to consolidate a session."""
        task = asyncio.create_task(
            self._consolidate_session(session),
            name=f"consolidate-session-{session.id}",
        )
        self._track_task(task)
        return task

    def schedule_fact_consolidation(
        self,
        *,
        app_name: str,
        user_id: str,
        session_id: str,
        raw_fact: str,
        tags: list[str] | None = None,
        simulated_delay_seconds: float = 0.0,
    ) -> asyncio.Task[ConsolidatedMemoryRecord | None]:
        """Launches a background task scrubbing PII and persisting an operational fact."""
        task = asyncio.create_task(
            self._consolidate_fact(
                app_name=app_name,
                user_id=user_id,
                session_id=session_id,
                raw_fact=raw_fact,
                tags=tags,
                simulated_delay_seconds=simulated_delay_seconds,
            ),
            name=f"consolidate-fact-{session_id}",
        )
        self._track_task(task)
        return task

    def _track_task(self, task: asyncio.Task[Any]) -> None:
        self._tasks.add(task)

        def _on_done(done_task: asyncio.Task[Any]) -> None:
            self._tasks.discard(done_task)
            if done_task.cancelled():
                return
            exc = done_task.exception()
            if exc is not None:
                self.failed_count += 1
                self.logger.error(
                    "memory.consolidation.failed",
                    task_name=done_task.get_name(),
                    error=str(exc),
                )
            else:
                self.completed_count += 1

        task.add_done_callback(_on_done)

    async def _consolidate_session(self, session: Session) -> None:
        with traced_operation(
            "memory.async_consolidate_session",
            attributes={
                "adk.session_id": session.id,
                "adk.user_id": session.user_id,
            },
        ):
            await self.memory_service.add_session_to_memory(session)
            self.logger.info(
                "memory.consolidation.session_saved",
                session_id=session.id,
                user_id=session.user_id,
            )

    async def _consolidate_fact(
        self,
        *,
        app_name: str,
        user_id: str,
        session_id: str,
        raw_fact: str,
        tags: list[str] | None,
        simulated_delay_seconds: float,
    ) -> ConsolidatedMemoryRecord | None:
        with traced_operation(
            "memory.async_consolidate_fact",
            attributes={"adk.session_id": session_id, "adk.user_id": user_id},
        ):
            if simulated_delay_seconds > 0:
                await asyncio.sleep(simulated_delay_seconds)
            scrubbed = self.redactor.redact_text(raw_fact)
            if isinstance(self.memory_service, PersistentSQLiteMemoryService):
                record = await self.memory_service.store_consolidated_fact(
                    app_name=app_name,
                    user_id=user_id,
                    session_id=session_id,
                    fact_text=scrubbed,
                    tags=tags,
                )
            else:
                synthetic_session = Session(
                    id=session_id,
                    app_name=app_name,
                    user_id=user_id,
                    state={"consolidated_fact": scrubbed, "tags": tags or []},
                )
                await self.memory_service.add_session_to_memory(synthetic_session)
                record = ConsolidatedMemoryRecord(
                    memory_id=f"mem-{uuid.uuid4().hex[:12]}",
                    app_name=app_name,
                    user_id=user_id,
                    session_id=session_id,
                    summary=scrubbed,
                    content_hash=hashlib.sha256(scrubbed.encode("utf-8")).hexdigest(),
                    tags=tags or [],
                    created_at_utc=datetime.now(timezone.utc).isoformat(),
                )
            self.logger.info(
                "memory.consolidation.fact_saved",
                session_id=session_id,
                user_id=user_id,
                tags=tags or [],
            )
            return record

    async def drain(self, timeout: float = 10.0) -> None:
        """Waits for all in-flight background memory consolidation tasks to complete."""
        if not self._tasks:
            return
        pending = list(self._tasks)
        await asyncio.wait_for(
            asyncio.gather(*pending, return_exceptions=True),
            timeout=timeout,
        )


def create_memory_service(
    *,
    settings: AppSettings | None = None,
    db_path: str | Path | None = None,
) -> BaseMemoryService:
    """Creates a Vertex AI Memory Bank service in GCP or persistent SQLite locally."""
    cfg = settings or get_settings()
    if cfg.agent_engine_id and cfg.gcp_project_id and db_path is None:
        return VertexAiMemoryBankService(
            project=cfg.gcp_project_id,
            location=cfg.gcp_region,
            agent_engine_id=cfg.agent_engine_id,
        )
    return PersistentSQLiteMemoryService(db_path=db_path or cfg.memory_db_path)
