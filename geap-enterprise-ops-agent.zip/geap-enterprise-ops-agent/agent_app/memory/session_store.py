"""Persistent Session State and Enterprise Operations Knowledge Store.

Provides:
1. ``create_session_service``: Connects the ADK Runner to a persistent database
   (ADK ``DatabaseSessionService`` over SQLite/Cloud SQL Postgres, or
   ``VertexAiSessionService`` when deployed on Vertex AI Agent Engine).
2. ``PersistentOpsKnowledgeStore``: SQLite-backed persistent runbook vector
   retriever (cosine similarity over tokenized TF-IDF embeddings) and incident
   ticket/audit log store that persists state cleanly across turns and restarts.
"""

from __future__ import annotations

import json
import math
import os
import re
import sqlite3
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from google.adk.sessions import (
    BaseSessionService,
    DatabaseSessionService,
    VertexAiSessionService,
)

from agent_app.config.secrets import AppSettings, get_settings
from agent_app.observability.pii_redactor import PIIRedactor, get_default_redactor

_TOKEN_RE = re.compile(r"[a-z0-9]+")

_SEED_RUNBOOKS: list[dict[str, Any]] = [
    {
        "runbook_id": "RB-PAY-001",
        "title": "Payments API Elevated 5xx / Latency Spike & Safe Rollback",
        "service_name": "payments-api",
        "severity_scope": "P0/P1",
        "keywords": "payments timeout 5xx latency database connection pool stripe rollback spike error rate",
        "recommended_steps": [
            "Verify error rate and p99 latency via fetch_service_health_metrics(service_name='payments-api').",
            "Check recent deployment diff between active_version and last_good_version.",
            "Open a P1/P0 incident ticket via create_critical_incident_ticket referencing RB-PAY-001.",
            "Request human-approved production rollback via execute_production_service_rollback.",
        ],
        "requires_human_approval": True,
    },
    {
        "runbook_id": "RB-CHK-002",
        "title": "Checkout Web Frontend Timeout & CDN Cache Invalidation",
        "service_name": "checkout-web",
        "severity_scope": "P1/P2",
        "keywords": "checkout web frontend slow latency cdn cache timeout cart error",
        "recommended_steps": [
            "Inspect checkout-web telemetry and downstream payments-api error rates.",
            "Validate edge cache hit ratio and warm regional CDN POPs.",
            "Escalate to checkout-oncall via create_critical_incident_ticket if p99 > 600ms.",
        ],
        "requires_human_approval": False,
    },
    {
        "runbook_id": "RB-AUTH-003",
        "title": "Auth Gateway JWT Signing Key Rotation & Token Failure Recovery",
        "service_name": "auth-gateway",
        "severity_scope": "P0/P1",
        "keywords": "auth gateway jwt token 401 403 oauth login failure certificate rotation",
        "recommended_steps": [
            "Confirm 401/403 spike and availability drop on auth-gateway.",
            "Verify JWKS endpoint freshness and Secret Manager key version alignment.",
            "Create P0 incident ticket immediately and notify Identity SRE on-call.",
            "Schedule emergency key rotation or request HITL rollback to last_good_version.",
        ],
        "requires_human_approval": True,
    },
    {
        "runbook_id": "RB-DB-004",
        "title": "Orders DB Primary Replication Lag & Maintenance Failover",
        "service_name": "orders-db",
        "severity_scope": "P1/P2",
        "keywords": "orders database postgres replication lag deadlock connection exhaustion maintenance",
        "recommended_steps": [
            "Inspect orders-db connection saturation and replica lag metrics.",
            "Identify long-running analytical queries blocking OLTP transactions.",
            "File P1 incident ticket if SLA breached and schedule approved maintenance window for index rebuild.",
        ],
        "requires_human_approval": True,
    },
    {
        "runbook_id": "RB-INV-005",
        "title": "Inventory Sync Pub/Sub Backlog Drain Procedure",
        "service_name": "inventory-sync",
        "severity_scope": "P2/P3",
        "keywords": "inventory sync pubsub queue backlog lag worker consumer retry",
        "recommended_steps": [
            "Check inventory-sync consumer lag and dead-letter queue depth.",
            "Scale horizontal worker replicas within autoscaling budget.",
            "Verify backlog drains within 15 minutes and update incident notes.",
        ],
        "requires_human_approval": False,
    },
]


def _tokenize(text: str) -> list[str]:
    return _TOKEN_RE.findall(text.lower())


def _cosine_similarity(vec_a: dict[str, float], vec_b: dict[str, float]) -> float:
    if not vec_a or not vec_b:
        return 0.0
    common = set(vec_a.keys()) & set(vec_b.keys())
    dot = sum(vec_a[k] * vec_b[k] for k in common)
    norm_a = math.sqrt(sum(v * v for v in vec_a.values()))
    norm_b = math.sqrt(sum(v * v for v in vec_b.values()))
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    return dot / (norm_a * norm_b)


def _ensure_sqlite_parent_dir(db_url: str) -> None:
    """Ensures local parent directory exists for SQLite SQLAlchemy URLs."""
    for prefix in ("sqlite+aiosqlite:///", "sqlite:///"):
        if db_url.startswith(prefix):
            raw_path = db_url[len(prefix) :]
            if raw_path and raw_path != ":memory:":
                Path(raw_path).expanduser().parent.mkdir(parents=True, exist_ok=True)


def create_session_service(
    *,
    settings: AppSettings | None = None,
    db_url: str | None = None,
) -> BaseSessionService:
    """Creates a persistent ADK session service backed by a database or Vertex AI.

    Uses ``VertexAiSessionService`` when deployed to Vertex AI Agent Engine
    (``AGENT_ENGINE_ID`` + ``GCP_PROJECT_ID`` configured), and otherwise uses
    ADK's persistent ``DatabaseSessionService`` (SQLite/Cloud SQL Postgres).
    """
    cfg = settings or get_settings()
    if cfg.agent_engine_id and cfg.gcp_project_id and db_url is None:
        return VertexAiSessionService(
            project=cfg.gcp_project_id,
            location=cfg.gcp_region,
            agent_engine_id=cfg.agent_engine_id,
        )

    effective_url = db_url or cfg.session_db_url
    _ensure_sqlite_parent_dir(effective_url)
    return DatabaseSessionService(db_url=effective_url)


class PersistentOpsKnowledgeStore:
    """Persistent SQLite vector/TF-IDF runbook store and incident ledger."""

    def __init__(
        self,
        db_path: str | Path | None = None,
        *,
        redactor: PIIRedactor | None = None,
    ) -> None:
        resolved = Path(db_path or get_settings().knowledge_db_path).expanduser()
        resolved.parent.mkdir(parents=True, exist_ok=True)
        self.db_path = str(resolved)
        self.redactor = redactor or get_default_redactor()
        self._init_schema()
        self._seed_default_runbooks()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS runbooks (
                    runbook_id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    service_name TEXT NOT NULL,
                    severity_scope TEXT NOT NULL,
                    keywords TEXT NOT NULL,
                    recommended_steps_json TEXT NOT NULL,
                    requires_human_approval INTEGER NOT NULL DEFAULT 0,
                    term_freq_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS incident_tickets (
                    ticket_id TEXT PRIMARY KEY,
                    service_name TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    summary TEXT NOT NULL,
                    root_cause_hypothesis TEXT NOT NULL,
                    runbook_id TEXT,
                    assigned_oncall_team TEXT NOT NULL,
                    sla_response_minutes INTEGER NOT NULL,
                    created_at_utc TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS audit_actions (
                    action_id TEXT PRIMARY KEY,
                    action_type TEXT NOT NULL,
                    service_name TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    approved_by TEXT NOT NULL,
                    created_at_utc TEXT NOT NULL
                );
                """
            )

    def _seed_default_runbooks(self) -> None:
        with self._connect() as conn:
            existing = conn.execute("SELECT COUNT(*) FROM runbooks").fetchone()[0]
            if existing > 0:
                return
            for rb in _SEED_RUNBOOKS:
                doc_text = " ".join(
                    [
                        rb["title"],
                        rb["service_name"],
                        rb["keywords"],
                        " ".join(rb["recommended_steps"]),
                    ]
                )
                tf = Counter(_tokenize(doc_text))
                conn.execute(
                    """
                    INSERT OR REPLACE INTO runbooks (
                        runbook_id, title, service_name, severity_scope,
                        keywords, recommended_steps_json, requires_human_approval,
                        term_freq_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        rb["runbook_id"],
                        rb["title"],
                        rb["service_name"],
                        rb["severity_scope"],
                        rb["keywords"],
                        json.dumps(rb["recommended_steps"]),
                        1 if rb["requires_human_approval"] else 0,
                        json.dumps(dict(tf)),
                    ),
                )

    def search_runbooks(
        self,
        query: str,
        *,
        service_name: str | None = None,
        top_k: int = 3,
    ) -> list[dict[str, Any]]:
        """Retrieves top-k runbooks via TF-IDF cosine similarity over SQLite storage."""
        query_tokens = _tokenize(query)
        if service_name:
            query_tokens.extend(_tokenize(service_name))
        query_tf = Counter(query_tokens)

        with self._connect() as conn:
            if service_name:
                rows = conn.execute(
                    "SELECT * FROM runbooks WHERE service_name = ?",
                    (service_name.strip().lower(),),
                ).fetchall()
            else:
                rows = conn.execute("SELECT * FROM runbooks").fetchall()

        if not rows:
            return []

        # Compute inverse document frequency across stored runbooks.
        num_docs = len(rows)
        doc_freq: Counter[str] = Counter()
        parsed_docs: list[tuple[sqlite3.Row, dict[str, int]]] = []
        for row in rows:
            tf = json.loads(row["term_freq_json"])
            parsed_docs.append((row, tf))
            for term in tf:
                doc_freq[term] += 1

        def _tfidf(tf_map: dict[str, int]) -> dict[str, float]:
            return {
                term: count * (math.log((num_docs + 1) / (doc_freq.get(term, 0) + 1)) + 1.0)
                for term, count in tf_map.items()
            }

        query_vec = _tfidf(dict(query_tf))
        scored: list[dict[str, Any]] = []
        for row, doc_tf in parsed_docs:
            score = _cosine_similarity(query_vec, _tfidf(doc_tf))
            if service_name and row["service_name"] == service_name.strip().lower():
                score = min(1.0, score + 0.15)
            scored.append(
                {
                    "runbook_id": row["runbook_id"],
                    "title": row["title"],
                    "service_name": row["service_name"],
                    "severity_scope": row["severity_scope"],
                    "relevance_score": round(float(score), 4),
                    "recommended_steps": json.loads(row["recommended_steps_json"]),
                    "requires_human_approval": bool(row["requires_human_approval"]),
                }
            )

        scored.sort(key=lambda item: item["relevance_score"], reverse=True)
        return scored[:top_k]

    def save_incident_ticket(self, ticket: dict[str, Any]) -> None:
        """Persists a PII-scrubbed incident ticket record to SQLite."""
        clean_summary = self.redactor.redact_text(ticket["summary"])
        clean_hypothesis = self.redactor.redact_text(ticket["root_cause_hypothesis"])
        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO incident_tickets (
                    ticket_id, service_name, severity, summary,
                    root_cause_hypothesis, runbook_id, assigned_oncall_team,
                    sla_response_minutes, created_at_utc
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    ticket["ticket_id"],
                    ticket["service_name"],
                    ticket["severity"],
                    clean_summary,
                    clean_hypothesis,
                    ticket.get("runbook_id"),
                    ticket["assigned_oncall_team"],
                    ticket["sla_response_minutes"],
                    ticket["created_at_utc"],
                ),
            )

    def get_incident_ticket(self, ticket_id: str) -> dict[str, Any] | None:
        """Retrieves a persisted incident ticket by ID."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM incident_tickets WHERE ticket_id = ?", (ticket_id,)
            ).fetchone()
        return dict(row) if row else None

    def record_audit_action(
        self,
        *,
        action_id: str,
        action_type: str,
        service_name: str,
        payload: dict[str, Any],
        approved_by: str,
    ) -> None:
        """Persists an approved high-stakes operational action for audit trails."""
        redacted_payload = self.redactor.redact_payload(payload)
        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO audit_actions (
                    action_id, action_type, service_name, payload_json,
                    approved_by, created_at_utc
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    action_id,
                    action_type,
                    service_name,
                    json.dumps(redacted_payload, sort_keys=True),
                    approved_by,
                    datetime.now(timezone.utc).isoformat(),
                ),
            )


_DEFAULT_STORE: PersistentOpsKnowledgeStore | None = None


def get_default_knowledge_store() -> PersistentOpsKnowledgeStore:
    """Returns or lazily initializes the default SQLite knowledge store."""
    global _DEFAULT_STORE
    target = os.getenv("OPS_KNOWLEDGE_DB_PATH") or get_settings().knowledge_db_path
    if _DEFAULT_STORE is None or _DEFAULT_STORE.db_path != str(Path(target).expanduser()):
        _DEFAULT_STORE = PersistentOpsKnowledgeStore(db_path=target)
    return _DEFAULT_STORE
