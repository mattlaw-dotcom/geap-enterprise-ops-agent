"""Structured JSON logging powered by structlog with OTel context & PII redaction.

All runtime logs are serialized as machine-parseable JSON objects enriched with
ISO-8601 UTC timestamps, log level, logger name, active OpenTelemetry trace/span
IDs, and automatic PII redaction before output.
"""

from __future__ import annotations

import logging
import sys
from typing import Any, TextIO

import structlog

from agent_app.observability.pii_redactor import PIIRedactor, get_default_redactor
from agent_app.observability.tracing import get_current_trace_context


def _inject_otel_trace_context(
    _logger: Any, _method_name: str, event_dict: dict[str, Any]
) -> dict[str, Any]:
    """Structlog processor injecting active OpenTelemetry trace_id and span_id."""
    trace_ctx = get_current_trace_context()
    event_dict.setdefault("trace_id", trace_ctx["trace_id"])
    event_dict.setdefault("span_id", trace_ctx["span_id"])
    event_dict.setdefault("service", "geap-enterprise-ops-agent")
    return event_dict


_UNREDACTED_METADATA_KEYS = frozenset(
    {"trace_id", "span_id", "timestamp_utc", "level", "service", "event"}
)


def _make_pii_redaction_processor(redactor: PIIRedactor):
    """Creates a structlog processor scrubbing all string fields before JSON emission."""

    def _redact_event(
        _logger: Any, _method_name: str, event_dict: dict[str, Any]
    ) -> dict[str, Any]:
        cleaned: dict[str, Any] = {}
        for key, value in event_dict.items():
            if key in _UNREDACTED_METADATA_KEYS:
                cleaned[key] = value
            else:
                cleaned[key] = redactor.redact_payload({key: value})[key]
        return cleaned

    return _redact_event


def configure_structured_logging(
    *,
    level: int = logging.INFO,
    stream: TextIO | None = None,
    redactor: PIIRedactor | None = None,
) -> None:
    """Configures structlog + stdlib logging to emit PII-scrubbed JSON lines."""
    active_redactor = redactor or get_default_redactor()
    target_stream = stream or sys.stdout

    logging.basicConfig(
        format="%(message)s",
        stream=target_stream,
        level=level,
        force=True,
    )

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso", utc=True, key="timestamp_utc"),
            _inject_otel_trace_context,
            _make_pii_redaction_processor(active_redactor),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(sort_keys=True),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(level),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(file=target_stream),
        cache_logger_on_first_use=False,
    )


def get_logger(name: str = "geap.enterprise_ops_agent") -> Any:
    """Returns a bound structlog JSON logger."""
    return structlog.get_logger(name)
