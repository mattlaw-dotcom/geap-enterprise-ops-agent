"""ADK Observability Plugin capturing Intent vs. Outcome logs and OTel spans.

Implements ``google.adk.plugins.BasePlugin`` to instrument every invocation,
agent stage, model request, and tool execution with:
1. Linked OpenTelemetry distributed trace spans (`invocation -> agent -> tool/model`).
2. Explicit **Intent** logs emitted BEFORE tool/agent execution (`agent.action.intent`).
3. Explicit **Outcome** logs emitted AFTER execution (`agent.action.outcome`) correlated
   by `intent_id` with latency, outcome classification, and `intent_matched_outcome`.
4. Automatic PII redaction across all logged parameters and tool responses.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

from google.adk.agents.base_agent import BaseAgent
from google.adk.agents.callback_context import CallbackContext
from google.adk.agents.invocation_context import InvocationContext
from google.adk.models.llm_request import LlmRequest
from google.adk.models.llm_response import LlmResponse
from google.adk.plugins.base_plugin import BasePlugin
from google.adk.tools.base_tool import BaseTool
from google.adk.tools.tool_context import ToolContext
from google.genai import types
from opentelemetry import trace
from opentelemetry.trace import Span, Status, StatusCode

from agent_app.observability.logging_config import get_logger
from agent_app.observability.pii_redactor import PIIRedactor, get_default_redactor
from agent_app.observability.tracing import get_current_trace_context, get_tracer


@dataclass
class IntentOutcomeRecord:
    """Correlated audit record comparing an agent's intended action vs. actual outcome."""

    intent_id: str
    agent_name: str
    action_type: str  # "tool_call" | "agent_stage" | "model_call"
    action_name: str
    intended_action: str
    intended_args_redacted: dict[str, Any] = field(default_factory=dict)
    started_at_utc: str = ""
    completed_at_utc: str = ""
    latency_ms: float = 0.0
    outcome_status: str = "pending"
    outcome_summary_redacted: dict[str, Any] = field(default_factory=dict)
    intent_matched_outcome: bool = False
    trace_id: str = ""
    span_id: str = ""


class ObservabilityPlugin(BasePlugin):
    """ADK Plugin for structured Intent-vs-Outcome logging and OpenTelemetry tracing."""

    def __init__(
        self,
        *,
        name: str = "enterprise_observability_plugin",
        redactor: PIIRedactor | None = None,
    ) -> None:
        super().__init__(name=name)
        self.redactor = redactor or get_default_redactor()
        self.logger = get_logger("geap.observability")
        self.records: list[IntentOutcomeRecord] = []
        self._active_spans: dict[str, tuple[Span, Any]] = {}
        self._pending_intents: dict[str, tuple[IntentOutcomeRecord, float]] = {}

    def _start_span(
        self, key: str, span_name: str, attributes: dict[str, Any]
    ) -> Span:
        tracer = get_tracer("geap.adk.plugin")
        span = tracer.start_span(span_name)
        for attr_key, attr_val in attributes.items():
            if attr_val is not None:
                span.set_attribute(attr_key, attr_val)
        token = trace.context_api.attach(trace.set_span_in_context(span))
        self._active_spans[key] = (span, token)
        return span

    def _end_span(
        self,
        key: str,
        *,
        attributes: dict[str, Any] | None = None,
        error: Exception | None = None,
    ) -> None:
        entry = self._active_spans.pop(key, None)
        if entry is None:
            return
        span, token = entry
        try:
            if attributes:
                for attr_key, attr_val in attributes.items():
                    if attr_val is not None:
                        span.set_attribute(attr_key, attr_val)
            if error is not None:
                span.record_exception(error)
                span.set_status(Status(StatusCode.ERROR, str(error)))
            else:
                span.set_status(Status(StatusCode.OK))
        finally:
            span.end()
            try:
                trace.context_api.detach(token)
            except ValueError:
                # Async generator frames can switch contextvars between before/after hooks.
                pass

    def _close_dangling_spans(self, *, prefix: str, reason: str) -> None:
        """Closes any child spans left open when another plugin short-circuited execution."""
        dangling_keys = [k for k in list(self._active_spans.keys()) if k.startswith(prefix)]
        for key in dangling_keys:
            self._end_span(key, attributes={"span.short_circuited_reason": reason})

    async def before_run_callback(
        self, *, invocation_context: InvocationContext
    ) -> Optional[types.Content]:
        inv_id = invocation_context.invocation_id
        session_id = invocation_context.session.id if invocation_context.session else "unknown"
        self._start_span(
            f"run:{inv_id}",
            "adk.invocation.run",
            {
                "adk.invocation_id": inv_id,
                "adk.session_id": session_id,
                "adk.app_name": invocation_context.app_name,
            },
        )
        self.logger.info(
            "invocation.started",
            invocation_id=inv_id,
            session_id=session_id,
            app_name=invocation_context.app_name,
        )
        return None

    async def after_run_callback(
        self, *, invocation_context: InvocationContext
    ) -> None:
        inv_id = invocation_context.invocation_id
        self._close_dangling_spans(
            prefix=f"model:{inv_id}:", reason="short_circuited_before_run_end"
        )
        self.logger.info(
            "invocation.completed",
            invocation_id=inv_id,
            recorded_actions=len(self.records),
        )
        self._end_span(f"run:{inv_id}")

    async def before_agent_callback(
        self, *, agent: BaseAgent, callback_context: CallbackContext
    ) -> Optional[types.Content]:
        inv_id = getattr(callback_context, "invocation_id", "unknown")
        key = f"agent:{inv_id}:{agent.name}"
        intent_id = f"int-{uuid.uuid4().hex[:10]}"
        self._start_span(
            key,
            f"adk.agent.{agent.name}",
            {
                "agent.name": agent.name,
                "adk.invocation_id": inv_id,
                "intent.id": intent_id,
            },
        )
        trace_ctx = get_current_trace_context()
        record = IntentOutcomeRecord(
            intent_id=intent_id,
            agent_name=agent.name,
            action_type="agent_stage",
            action_name=agent.name,
            intended_action=f"Execute workflow stage '{agent.name}'",
            started_at_utc=datetime.now(timezone.utc).isoformat(),
            trace_id=trace_ctx["trace_id"],
            span_id=trace_ctx["span_id"],
        )
        self._pending_intents[key] = (record, time.perf_counter())
        self.logger.info(
            "agent.action.intent",
            intent_id=intent_id,
            action_type="agent_stage",
            agent_name=agent.name,
            intended_action=record.intended_action,
        )
        return None

    async def after_agent_callback(
        self, *, agent: BaseAgent, callback_context: CallbackContext
    ) -> Optional[types.Content]:
        inv_id = getattr(callback_context, "invocation_id", "unknown")
        key = f"agent:{inv_id}:{agent.name}"
        pending = self._pending_intents.pop(key, None)
        if pending is not None:
            record, start_ts = pending
            record.completed_at_utc = datetime.now(timezone.utc).isoformat()
            record.latency_ms = round((time.perf_counter() - start_ts) * 1000, 2)
            record.outcome_status = "success"
            record.intent_matched_outcome = True
            self.records.append(record)
            self.logger.info(
                "agent.action.outcome",
                intent_id=record.intent_id,
                action_type="agent_stage",
                agent_name=agent.name,
                outcome_status=record.outcome_status,
                latency_ms=record.latency_ms,
                intent_matched_outcome=record.intent_matched_outcome,
            )
        self._close_dangling_spans(
            prefix=f"model:{inv_id}:{agent.name}",
            reason="short_circuited_by_guardrail_plugin",
        )
        self._end_span(key, attributes={"outcome.status": "success"})
        return None

    async def before_model_callback(
        self, *, callback_context: CallbackContext, llm_request: LlmRequest
    ) -> Optional[LlmResponse]:
        agent_name = getattr(callback_context, "agent_name", "unknown_agent")
        inv_id = getattr(callback_context, "invocation_id", "unknown")
        model_name = getattr(llm_request, "model", "unknown_model")
        key = f"model:{inv_id}:{agent_name}"
        self._start_span(
            key,
            f"gen_ai.model.{model_name}",
            {
                "gen_ai.system": "google_gemini",
                "gen_ai.request.model": str(model_name),
                "agent.name": agent_name,
            },
        )
        self.logger.info(
            "model.request.intent",
            agent_name=agent_name,
            model=str(model_name),
            content_parts=len(llm_request.contents or []),
        )
        return None

    async def after_model_callback(
        self, *, callback_context: CallbackContext, llm_response: LlmResponse
    ) -> Optional[LlmResponse]:
        agent_name = getattr(callback_context, "agent_name", "unknown_agent")
        inv_id = getattr(callback_context, "invocation_id", "unknown")
        key = f"model:{inv_id}:{agent_name}"
        self.logger.info(
            "model.response.outcome",
            agent_name=agent_name,
            has_content=llm_response.content is not None,
        )
        self._end_span(key, attributes={"gen_ai.response.has_content": llm_response.content is not None})
        return None

    async def before_tool_callback(
        self,
        *,
        tool: BaseTool,
        tool_args: dict[str, Any],
        tool_context: ToolContext,
    ) -> Optional[dict[str, Any]]:
        agent_name = getattr(tool_context, "agent_name", "unknown_agent")
        call_id = getattr(tool_context, "function_call_id", None) or uuid.uuid4().hex[:8]
        key = f"tool:{tool.name}:{call_id}"
        intent_id = f"int-{uuid.uuid4().hex[:10]}"
        redacted_args = self.redactor.redact_payload(tool_args)

        self._start_span(
            key,
            f"adk.tool.{tool.name}",
            {
                "tool.name": tool.name,
                "agent.name": agent_name,
                "intent.id": intent_id,
            },
        )
        trace_ctx = get_current_trace_context()
        record = IntentOutcomeRecord(
            intent_id=intent_id,
            agent_name=agent_name,
            action_type="tool_call",
            action_name=tool.name,
            intended_action=f"Invoke tool '{tool.name}' with validated parameters",
            intended_args_redacted=redacted_args,
            started_at_utc=datetime.now(timezone.utc).isoformat(),
            trace_id=trace_ctx["trace_id"],
            span_id=trace_ctx["span_id"],
        )
        self._pending_intents[key] = (record, time.perf_counter())
        self.logger.info(
            "agent.action.intent",
            intent_id=intent_id,
            action_type="tool_call",
            agent_name=agent_name,
            tool_name=tool.name,
            intended_action=record.intended_action,
            tool_args=redacted_args,
        )
        return None

    async def after_tool_callback(
        self,
        *,
        tool: BaseTool,
        tool_args: dict[str, Any],
        tool_context: ToolContext,
        result: dict[str, Any],
    ) -> Optional[dict[str, Any]]:
        call_id = getattr(tool_context, "function_call_id", None)
        key = self._resolve_pending_tool_key(tool.name, call_id)
        redacted_result = self.redactor.redact_payload(result)
        raw_status = result.get("status", "ok") if isinstance(result, dict) else "ok"
        if raw_status == "ok":
            outcome_status = "success"
            matched = True
        elif raw_status == "pending_human_approval":
            outcome_status = "pending_human_approval"
            matched = True
        elif raw_status == "blocked_by_policy":
            outcome_status = "blocked_by_policy"
            matched = False
        else:
            outcome_status = "error"
            matched = False

        pending = self._pending_intents.pop(key, None) if key else None
        if pending is not None:
            record, start_ts = pending
            record.completed_at_utc = datetime.now(timezone.utc).isoformat()
            record.latency_ms = round((time.perf_counter() - start_ts) * 1000, 2)
            record.outcome_status = outcome_status
            record.outcome_summary_redacted = (
                redacted_result if isinstance(redacted_result, dict) else {"value": redacted_result}
            )
            record.intent_matched_outcome = matched
            self.records.append(record)
            self.logger.info(
                "agent.action.outcome",
                intent_id=record.intent_id,
                action_type="tool_call",
                agent_name=record.agent_name,
                tool_name=tool.name,
                outcome_status=outcome_status,
                latency_ms=record.latency_ms,
                intent_matched_outcome=matched,
                outcome_summary=record.outcome_summary_redacted,
            )

        if key:
            self._end_span(
                key,
                attributes={
                    "tool.outcome_status": outcome_status,
                    "tool.intent_matched_outcome": matched,
                },
            )
        return None

    async def on_tool_error_callback(
        self,
        *,
        tool: BaseTool,
        tool_args: dict[str, Any],
        tool_context: ToolContext,
        error: Exception,
    ) -> Optional[dict[str, Any]]:
        call_id = getattr(tool_context, "function_call_id", None)
        key = self._resolve_pending_tool_key(tool.name, call_id)
        pending = self._pending_intents.pop(key, None) if key else None
        if pending is not None:
            record, start_ts = pending
            record.completed_at_utc = datetime.now(timezone.utc).isoformat()
            record.latency_ms = round((time.perf_counter() - start_ts) * 1000, 2)
            record.outcome_status = "exception"
            record.outcome_summary_redacted = {"error": self.redactor.redact_text(str(error))}
            record.intent_matched_outcome = False
            self.records.append(record)
            self.logger.error(
                "agent.action.outcome",
                intent_id=record.intent_id,
                action_type="tool_call",
                agent_name=record.agent_name,
                tool_name=tool.name,
                outcome_status="exception",
                latency_ms=record.latency_ms,
                intent_matched_outcome=False,
                error=self.redactor.redact_text(str(error)),
            )
        if key:
            self._end_span(key, error=error)
        return None

    def _resolve_pending_tool_key(self, tool_name: str, call_id: str | None) -> str | None:
        if call_id and f"tool:{tool_name}:{call_id}" in self._pending_intents:
            return f"tool:{tool_name}:{call_id}"
        prefix = f"tool:{tool_name}:"
        for key in reversed(list(self._pending_intents.keys())):
            if key.startswith(prefix):
                return key
        return None

    def get_intent_outcome_records(self) -> list[IntentOutcomeRecord]:
        """Returns all correlated Intent-vs-Outcome audit records."""
        return list(self.records)

    def clear_records(self) -> None:
        """Clears stored records (useful between isolated test runs)."""
        self.records.clear()
        self._pending_intents.clear()
