"""OpenTelemetry distributed tracing configuration and span helpers.

Links spans end-to-end across user invocation, SequentialAgent stages, LLM
model calls, tool executions, guardrail evaluations, and async memory
consolidation. Supports Cloud Trace / OTLP export in production and in-memory
span collection in local tests and CI.
"""

from __future__ import annotations

import os
from contextlib import contextmanager
from typing import Any, Iterator

from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import (
    BatchSpanProcessor,
    ConsoleSpanExporter,
    SimpleSpanProcessor,
    SpanExporter,
)
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace import Span, Status, StatusCode, Tracer

_TRACER_PROVIDER: TracerProvider | None = None
_MEMORY_EXPORTER: InMemorySpanExporter | None = None


def _resolve_cloud_exporter() -> SpanExporter | None:
    """Optionally initializes an OTLP or Google Cloud Trace exporter when configured."""
    otlp_endpoint = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT")
    if otlp_endpoint:
        try:  # pragma: no cover - optional production exporter
            from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
                OTLPSpanExporter,
            )

            return OTLPSpanExporter(endpoint=otlp_endpoint)
        except Exception:
            pass

    if os.getenv("ENABLE_OTEL_CLOUD_EXPORT", "false").lower() in {"1", "true", "yes"}:
        try:  # pragma: no cover - optional production exporter
            from opentelemetry.exporter.cloud_trace import CloudTraceSpanExporter

            return CloudTraceSpanExporter()
        except Exception:
            pass

    return None


def configure_tracing(
    *,
    service_name: str = "geap-enterprise-ops-agent",
    service_version: str = "1.0.0",
    environment: str | None = None,
    exporter: SpanExporter | None = None,
    use_in_memory_exporter: bool = False,
    enable_console_export: bool = False,
) -> tuple[TracerProvider, InMemorySpanExporter | None]:
    """Configures the OpenTelemetry TracerProvider with appropriate processors.

    Args:
        service_name: Logical OTel ``service.name`` resource attribute.
        service_version: Semantic version string attached to spans.
        environment: Deployment environment (e.g., ``prod``, ``staging``, ``test``).
        exporter: Optional explicit OTel ``SpanExporter`` (e.g., OTLP or Cloud Trace).
        use_in_memory_exporter: When True, attaches an ``InMemorySpanExporter`` for
            deterministic trace verification in tests and evals.
        enable_console_export: When True, emits spans to console output.

    Returns:
        Tuple of ``(TracerProvider, InMemorySpanExporter | None)``.
    """
    global _TRACER_PROVIDER, _MEMORY_EXPORTER

    env_name = environment or os.getenv("APP_ENV", "dev")
    resource = Resource.create(
        {
            "service.name": service_name,
            "service.version": service_version,
            "deployment.environment": env_name,
            "telemetry.framework": "google-adk",
        }
    )

    provider = TracerProvider(resource=resource)
    mem_exporter: InMemorySpanExporter | None = None

    active_exporter = exporter or _resolve_cloud_exporter()
    if active_exporter is not None:
        provider.add_span_processor(BatchSpanProcessor(active_exporter))

    if use_in_memory_exporter:
        mem_exporter = InMemorySpanExporter()
        provider.add_span_processor(SimpleSpanProcessor(mem_exporter))

    if enable_console_export:
        provider.add_span_processor(SimpleSpanProcessor(ConsoleSpanExporter()))

    _TRACER_PROVIDER = provider
    _MEMORY_EXPORTER = mem_exporter

    # Set global provider cleanly even if already initialized in an earlier test.
    try:
        trace.set_tracer_provider(provider)
    except Exception:  # pragma: no cover
        pass

    return provider, mem_exporter


def get_tracer(instrumentation_name: str = "geap.enterprise_ops_agent") -> Tracer:
    """Returns an OpenTelemetry tracer backed by the configured provider."""
    if _TRACER_PROVIDER is not None:
        return _TRACER_PROVIDER.get_tracer(instrumentation_name)
    return trace.get_tracer(instrumentation_name)


def get_memory_exporter() -> InMemorySpanExporter | None:
    """Returns the active InMemorySpanExporter if tracing was configured with one."""
    return _MEMORY_EXPORTER


def get_current_trace_context() -> dict[str, str]:
    """Extracts the active OpenTelemetry ``trace_id`` and ``span_id`` as hex strings."""
    span = trace.get_current_span()
    ctx = span.get_span_context() if span is not None else None
    if ctx is not None and ctx.is_valid:
        return {
            "trace_id": format(ctx.trace_id, "032x"),
            "span_id": format(ctx.span_id, "016x"),
        }
    return {"trace_id": "0" * 32, "span_id": "0" * 16}


@contextmanager
def traced_operation(
    span_name: str,
    *,
    attributes: dict[str, Any] | None = None,
    tracer_name: str = "geap.enterprise_ops_agent",
) -> Iterator[Span]:
    """Context manager creating a linked child OpenTelemetry span with error capture."""
    tracer = get_tracer(tracer_name)
    with tracer.start_as_current_span(span_name) as span:
        if attributes:
            for key, value in attributes.items():
                if value is not None:
                    span.set_attribute(key, value)
        try:
            yield span
        except Exception as exc:
            span.record_exception(exc)
            span.set_status(Status(StatusCode.ERROR, str(exc)))
            raise
