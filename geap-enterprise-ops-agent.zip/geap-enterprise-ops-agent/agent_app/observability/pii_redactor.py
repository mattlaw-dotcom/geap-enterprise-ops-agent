"""Hybrid PII & Secret Redactor using Google Cloud DLP with regex fallback.

Scrubs sensitive data (emails, SSNs, credit card numbers, phone numbers, IPv4
addresses, API keys, bearer tokens, and private secrets) before payloads enter
structured logs, persistent sessions, compacted history, or long-term memory.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Any

DEFAULT_DLP_INFO_TYPES: tuple[str, ...] = (
    "EMAIL_ADDRESS",
    "PHONE_NUMBER",
    "US_SOCIAL_SECURITY_NUMBER",
    "CREDIT_CARD_NUMBER",
    "IP_ADDRESS",
    "GCP_API_KEY",
    "AUTH_TOKEN",
)

# Ordered from most specific secret/credential formats to generic PII patterns.
_REGEX_RULES: tuple[tuple[str, re.Pattern[str], str], ...] = (
    (
        "GCP_API_KEY",
        re.compile(r"\bAIza[0-9A-Za-z\-_]{20,}\b"),
        "[REDACTED_GCP_API_KEY]",
    ),
    (
        "GITHUB_TOKEN",
        re.compile(r"\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{20,}\b"),
        "[REDACTED_GITHUB_TOKEN]",
    ),
    (
        "GENERIC_SECRET_KEY",
        re.compile(r"\b(?:sk|pk)_(?:live|test|prod)?_?[A-Za-z0-9]{16,}\b"),
        "[REDACTED_API_KEY]",
    ),
    (
        "BEARER_TOKEN",
        re.compile(r"(?i)\bBearer\s+[A-Za-z0-9\-._~+/]+=*"),
        "Bearer [REDACTED_TOKEN]",
    ),
    (
        "US_SOCIAL_SECURITY_NUMBER",
        re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
        "[REDACTED_SSN]",
    ),
    (
        "CREDIT_CARD_NUMBER",
        re.compile(r"\b(?:\d[ -]*?){13,19}\b"),
        "[REDACTED_CREDIT_CARD]",
    ),
    (
        "EMAIL_ADDRESS",
        re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
        "[REDACTED_EMAIL]",
    ),
    (
        "PHONE_NUMBER",
        re.compile(r"(?<!\w)(?:\+?1[-.\s]?)?(?:\(\d{3}\)|\d{3})[-.\s]\d{3}[-.\s]\d{4}(?!\w)"),
        "[REDACTED_PHONE]",
    ),
    (
        "IP_ADDRESS",
        re.compile(
            r"\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b"
        ),
        "[REDACTED_IP]",
    ),
)

_SENSITIVE_KEY_NAMES = frozenset(
    {
        "api_key",
        "apikey",
        "authorization",
        "password",
        "passwd",
        "secret",
        "secret_key",
        "access_token",
        "refresh_token",
        "private_key",
        "ssn",
        "credit_card",
    }
)


def _passes_luhn(digits: str) -> bool:
    """Validates candidate card digits with the Luhn check to avoid false positives."""
    if not (13 <= len(digits) <= 19) or not digits.isdigit():
        return False
    # Reject all-zero or single-repeated-digit strings (e.g., unset OTel span_id '0'*16).
    if len(set(digits)) == 1:
        return False
    checksum = 0
    parity = len(digits) % 2
    for idx, ch in enumerate(digits):
        digit = int(ch)
        if idx % 2 == parity:
            digit *= 2
            if digit > 9:
                digit -= 9
        checksum += digit
    return checksum % 10 == 0


@dataclass
class RedactionReport:
    """Result returned by PII redaction including counts and backend used."""

    redacted_text: str
    backend: str
    redactions_count: int = 0
    detected_types: dict[str, int] = field(default_factory=dict)


class PIIRedactor:
    """Redacts PII and credentials via Google Cloud DLP with automatic regex fallback."""

    def __init__(
        self,
        *,
        project_id: str | None = None,
        enable_cloud_dlp: bool | None = None,
        dlp_client: Any | None = None,
        info_types: tuple[str, ...] = DEFAULT_DLP_INFO_TYPES,
    ) -> None:
        self.project_id = (
            project_id
            or os.getenv("GCP_PROJECT_ID")
            or os.getenv("GOOGLE_CLOUD_PROJECT")
        )
        if enable_cloud_dlp is None:
            self.enable_cloud_dlp = os.getenv("ENABLE_CLOUD_DLP", "false").lower() in {
                "1",
                "true",
                "yes",
            }
        else:
            self.enable_cloud_dlp = enable_cloud_dlp
        self._dlp_client = dlp_client
        self.info_types = info_types

    def _get_dlp_client(self) -> Any:
        if self._dlp_client is None:
            from google.cloud import dlp_v2

            self._dlp_client = dlp_v2.DlpServiceClient()
        return self._dlp_client

    def _deidentify_with_cloud_dlp(self, text: str) -> RedactionReport | None:
        """Attempts de-identification via Google Cloud DLP API."""
        if not (self.enable_cloud_dlp and self.project_id):
            return None
        try:
            client = self._get_dlp_client()
            parent = f"projects/{self.project_id}/locations/global"
            inspect_config = {
                "info_types": [{"name": info_type} for info_type in self.info_types],
            }
            deidentify_config = {
                "info_type_transformations": {
                    "transformations": [
                        {
                            "primitive_transformation": {
                                "replace_with_info_type_config": {}
                            }
                        }
                    ]
                }
            }
            response = client.deidentify_content(
                request={
                    "parent": parent,
                    "deidentify_config": deidentify_config,
                    "inspect_config": inspect_config,
                    "item": {"value": text},
                }
            )
            redacted_value = response.item.value
            detected: dict[str, int] = {}
            total = 0
            overview = getattr(response, "overview", None)
            if overview is not None:
                for summary in getattr(overview, "transformation_summaries", []):
                    info_name = getattr(getattr(summary, "info_type", None), "name", "DLP_ENTITY")
                    for res in getattr(summary, "results", []):
                        count = int(getattr(res, "count", 0))
                        if count > 0:
                            detected[info_name] = detected.get(info_name, 0) + count
                            total += count
            if total == 0 and redacted_value != text:
                total = 1
                detected["CLOUD_DLP_ENTITY"] = 1
            return RedactionReport(
                redacted_text=redacted_value,
                backend="cloud_dlp",
                redactions_count=total,
                detected_types=detected,
            )
        except Exception:
            # Graceful deterministic fallback to local regex redactor.
            return None

    def _deidentify_with_regex(self, text: str) -> RedactionReport:
        """Applies deterministic compiled regex rules with Luhn validation for cards."""
        redacted = text
        detected: dict[str, int] = {}
        total = 0

        for entity_type, pattern, placeholder in _REGEX_RULES:
            if entity_type == "CREDIT_CARD_NUMBER":

                def _replace_card(match: re.Match[str]) -> str:
                    nonlocal total
                    raw = match.group(0)
                    digits = re.sub(r"\D", "", raw)
                    if _passes_luhn(digits):
                        detected[entity_type] = detected.get(entity_type, 0) + 1
                        total += 1
                        return placeholder
                    return raw

                redacted = pattern.sub(_replace_card, redacted)
            else:
                redacted, count = pattern.subn(placeholder, redacted)
                if count > 0:
                    detected[entity_type] = detected.get(entity_type, 0) + count
                    total += count

        return RedactionReport(
            redacted_text=redacted,
            backend="regex_fallback",
            redactions_count=total,
            detected_types=detected,
        )

    def redact_with_report(self, text: str) -> RedactionReport:
        """Redacts PII/secrets from text and returns detailed redaction metadata."""
        if not text:
            return RedactionReport(redacted_text=text, backend="noop", redactions_count=0)

        dlp_report = self._deidentify_with_cloud_dlp(text)
        if dlp_report is not None:
            # Run a second regex pass to guarantee secret tokens DLP may not classify.
            regex_pass = self._deidentify_with_regex(dlp_report.redacted_text)
            merged_types = dict(dlp_report.detected_types)
            for key, count in regex_pass.detected_types.items():
                merged_types[key] = merged_types.get(key, 0) + count
            return RedactionReport(
                redacted_text=regex_pass.redacted_text,
                backend="cloud_dlp+regex",
                redactions_count=dlp_report.redactions_count + regex_pass.redactions_count,
                detected_types=merged_types,
            )

        return self._deidentify_with_regex(text)

    def redact_text(self, text: str) -> str:
        """Redacts sensitive PII and secrets from a string."""
        return self.redact_with_report(text).redacted_text

    def redact_payload(self, payload: Any) -> Any:
        """Recursively redacts sensitive keys and values in nested dicts/lists."""
        if isinstance(payload, str):
            return self.redact_text(payload)
        if isinstance(payload, dict):
            cleaned: dict[str, Any] = {}
            for key, value in payload.items():
                key_lower = str(key).strip().lower()
                if key_lower in _SENSITIVE_KEY_NAMES and value is not None:
                    cleaned[key] = "[REDACTED_SECRET]"
                else:
                    cleaned[key] = self.redact_payload(value)
            return cleaned
        if isinstance(payload, list):
            return [self.redact_payload(item) for item in payload]
        if isinstance(payload, tuple):
            return tuple(self.redact_payload(item) for item in payload)
        return payload


_DEFAULT_REDACTOR = PIIRedactor()


def get_default_redactor() -> PIIRedactor:
    """Returns the process-wide default PIIRedactor instance."""
    return _DEFAULT_REDACTOR
