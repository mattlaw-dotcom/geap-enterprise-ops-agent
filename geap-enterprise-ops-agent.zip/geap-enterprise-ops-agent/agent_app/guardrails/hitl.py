"""Human-in-the-Loop (HITL) confirmation hooks for high-stakes production actions.

Implements explicit execution stops requiring verified human operator approval
before high-impact mutations (such as production rollbacks or maintenance window
scheduling) can run. Integrates with both ADK's native
``ToolContext.request_confirmation`` / ``ToolConfirmation`` workflow and a
verifiable ``HumanApprovalGate`` token store for deterministic testing and audits.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Literal

from agent_app.observability.logging_config import get_logger
from agent_app.observability.pii_redactor import PIIRedactor, get_default_redactor
from agent_app.observability.tracing import traced_operation
from agent_app.schemas import PendingApprovalResponse

HIGH_STAKES_TOOLS: dict[str, dict[str, str]] = {
    "execute_production_service_rollback": {
        "risk_level": "CRITICAL",
        "blast_radius": "Live production traffic for the target service will be shifted to a prior release.",
    },
    "schedule_maintenance_window": {
        "risk_level": "HIGH",
        "blast_radius": "Scheduled service downtime or degraded capacity affecting enterprise customers.",
    },
}


@dataclass
class ApprovalRecord:
    """State record tracking an individual HITL confirmation request."""

    approval_id: str
    tool_name: str
    risk_level: Literal["HIGH", "CRITICAL"]
    action_summary: str
    proposed_arguments: dict[str, Any]
    blast_radius: str
    status: Literal["pending", "approved", "rejected", "expired"] = "pending"
    requested_at_utc: str = ""
    expires_at_utc: str = ""
    approver_id: str | None = None
    decision_notes: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


class HumanApprovalGate:
    """Enforces mandatory human confirmation before high-stakes tool execution."""

    def __init__(
        self,
        *,
        ttl_minutes: int = 30,
        redactor: PIIRedactor | None = None,
    ) -> None:
        self.ttl_minutes = ttl_minutes
        self.redactor = redactor or get_default_redactor()
        self.logger = get_logger("geap.guardrails.hitl")
        self._records: dict[str, ApprovalRecord] = {}

    def requires_approval(self, tool_name: str) -> bool:
        """Returns True if the given tool requires explicit human confirmation."""
        return tool_name in HIGH_STAKES_TOOLS

    def request_approval(
        self,
        *,
        tool_name: str,
        tool_args: dict[str, Any],
        tool_context: Any | None = None,
    ) -> PendingApprovalResponse:
        """Creates a pending HITL approval request and invokes ADK confirmation if present."""
        with traced_operation(
            "hitl.request_approval",
            attributes={"tool.name": tool_name, "hitl.required": True},
        ):
            meta = HIGH_STAKES_TOOLS.get(
                tool_name,
                {
                    "risk_level": "HIGH",
                    "blast_radius": "Production operational state modification.",
                },
            )
            approval_id = f"APR-{uuid.uuid4().hex[:8].upper()}"
            now = datetime.now(timezone.utc)
            expires = now + timedelta(minutes=self.ttl_minutes)
            redacted_args = self.redactor.redact_payload(dict(tool_args))
            redacted_args.pop("approval_token", None)

            service = redacted_args.get("service_name", "unknown-service")
            action_summary = (
                f"Execute '{tool_name}' on service '{service}' "
                f"with args={redacted_args}"
            )
            risk_level: Literal["HIGH", "CRITICAL"] = (
                "CRITICAL" if meta["risk_level"] == "CRITICAL" else "HIGH"
            )

            record = ApprovalRecord(
                approval_id=approval_id,
                tool_name=tool_name,
                risk_level=risk_level,
                action_summary=action_summary,
                proposed_arguments=redacted_args,
                blast_radius=meta["blast_radius"],
                status="pending",
                requested_at_utc=now.isoformat(),
                expires_at_utc=expires.isoformat(),
            )
            self._records[approval_id] = record

            instructions = (
                f"HUMAN CONFIRMATION REQUIRED ({risk_level} RISK). "
                f"Review proposed action '{tool_name}' for '{service}'. "
                f"To proceed, an authorized SRE must approve request '{approval_id}' "
                f"and resume with approval_token='{approval_id}'."
            )

            # Hook directly into Google ADK's native ToolContext.request_confirmation when present.
            if tool_context is not None and hasattr(tool_context, "request_confirmation"):
                try:
                    tool_context.request_confirmation(
                        hint=instructions,
                        payload={
                            "approval_id": approval_id,
                            "tool_name": tool_name,
                            "risk_level": risk_level,
                            "proposed_arguments": redacted_args,
                        },
                    )
                except Exception:
                    # Graceful handling when invoked in standalone unit tests without invocation ctx.
                    pass

            self.logger.warning(
                "hitl.approval.requested",
                approval_id=approval_id,
                tool_name=tool_name,
                risk_level=risk_level,
                service_name=service,
            )

            return PendingApprovalResponse(
                approval_id=approval_id,
                tool_name=tool_name,
                risk_level=risk_level,
                action_summary=action_summary,
                proposed_arguments=redacted_args,
                blast_radius=meta["blast_radius"],
                approval_instructions=instructions,
            )

    def grant_approval(
        self,
        approval_id: str,
        *,
        approver_id: str,
        notes: str = "Approved by SRE on-call.",
    ) -> ApprovalRecord:
        """Records explicit human approval for a pending HITL request."""
        if not approver_id or "@" not in approver_id:
            raise ValueError("approver_id must be a valid corporate email identifier.")
        record = self._records.get(approval_id)
        if record is None:
            raise KeyError(f"Unknown approval_id '{approval_id}'.")
        if record.status == "rejected":
            raise ValueError(f"Approval '{approval_id}' was already rejected.")

        record.status = "approved"
        record.approver_id = approver_id
        record.decision_notes = self.redactor.redact_text(notes)
        self.logger.info(
            "hitl.approval.granted",
            approval_id=approval_id,
            tool_name=record.tool_name,
            approver_role="authorized_sre",
        )
        return record

    def reject_approval(
        self,
        approval_id: str,
        *,
        approver_id: str,
        reason: str,
    ) -> ApprovalRecord:
        """Records explicit human rejection for a pending HITL request."""
        record = self._records.get(approval_id)
        if record is None:
            raise KeyError(f"Unknown approval_id '{approval_id}'.")
        record.status = "rejected"
        record.approver_id = approver_id
        record.decision_notes = self.redactor.redact_text(reason)
        self.logger.warning(
            "hitl.approval.rejected",
            approval_id=approval_id,
            tool_name=record.tool_name,
        )
        return record

    def verify_approval(
        self,
        *,
        tool_name: str,
        approval_token: str | None = None,
        tool_context: Any | None = None,
    ) -> tuple[bool, str | None]:
        """Checks whether a valid human confirmation exists for ``tool_name``.

        Checks two authoritative sources:
        1. ADK native ``tool_context.tool_confirmation`` (``confirmed is True``).
        2. Verified ``approval_token`` matching an unexpired ``approved`` record
           in ``HumanApprovalGate`` for the exact ``tool_name``.
        """
        # 1. Check native ADK ToolConfirmation on resumed invocations.
        if tool_context is not None:
            confirmation = getattr(tool_context, "tool_confirmation", None)
            if confirmation is not None and getattr(confirmation, "confirmed", False) is True:
                payload = getattr(confirmation, "payload", None) or {}
                approver = (
                    payload.get("approver_id", "adk-human-operator")
                    if isinstance(payload, dict)
                    else "adk-human-operator"
                )
                return True, str(approver)

            # Also check session state approvals map if set by an external HITL UI.
            state = getattr(tool_context, "state", None)
            if state is not None and hasattr(state, "get") and not approval_token:
                state_approvals = state.get("hitl_approvals", {})
                if isinstance(state_approvals, dict) and tool_name in state_approvals:
                    approval_token = str(state_approvals[tool_name])

        # 2. Verify explicit token against the gate registry.
        if not approval_token:
            return False, None

        record = self._records.get(approval_token)
        if record is None or record.tool_name != tool_name:
            return False, None
        if record.status != "approved":
            return False, None

        expires_at = datetime.fromisoformat(record.expires_at_utc)
        if datetime.now(timezone.utc) > expires_at:
            record.status = "expired"
            return False, None

        return True, record.approver_id or "verified-human-operator"

    def get_record(self, approval_id: str) -> ApprovalRecord | None:
        """Returns the ApprovalRecord for inspection."""
        return self._records.get(approval_id)

    def clear(self) -> None:
        """Clears all records (for isolated tests)."""
        self._records.clear()


_DEFAULT_HITL_GATE = HumanApprovalGate()


def get_default_hitl_gate() -> HumanApprovalGate:
    """Returns the shared default HumanApprovalGate instance."""
    return _DEFAULT_HITL_GATE
