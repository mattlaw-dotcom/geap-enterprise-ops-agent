"""ADK Policy, Security, Self-Evaluation & HITL Guardrail Plugin.

Implements ``google.adk.plugins.BasePlugin`` plus reusable ADK callbacks to
enforce enterprise safety before model calls, after model calls, and before tool
execution:
1. ``before_model_callback``:
   - Prompt injection / jailbreak / system prompt exfiltration detection.
   - Optional Google Cloud Model Armor screening hook (``MODEL_ARMOR_TEMPLATE_ID``).
   - Active PII redaction of user content before sending to the LLM.
   - Token-budget history compaction to prevent context window bloat.
2. ``before_tool_callback``:
   - Service scope & policy validation (blocks wildcard/destructive targets).
   - Mandatory Human-in-the-Loop (HITL) pause for high-stakes production tools.
3. ``after_model_callback``:
   - Automated self-evaluation checking grounding, secret/PII leakage, and
     unverified mutation claims, scrubbing any leaked PII before returning.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Any, Optional

from google.adk.agents.callback_context import CallbackContext
from google.adk.agents.invocation_context import InvocationContext
from google.adk.models.llm_request import LlmRequest
from google.adk.models.llm_response import LlmResponse
from google.adk.plugins.base_plugin import BasePlugin
from google.adk.tools.base_tool import BaseTool
from google.adk.tools.tool_context import ToolContext
from google.genai import types

from agent_app.guardrails.hitl import HumanApprovalGate, get_default_hitl_gate
from agent_app.memory.compaction import ContextCompactor, extract_text_from_contents
from agent_app.observability.logging_config import get_logger
from agent_app.observability.pii_redactor import PIIRedactor, get_default_redactor
from agent_app.observability.tracing import traced_operation
from agent_app.schemas import IncidentTriageReport, ToolErrorResponse

_INJECTION_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    (
        "instruction_override",
        re.compile(
            r"(?i)\b(?:ignore|disregard|forget|override)\s+(?:all\s+)?(?:previous|prior|above|system)\s+(?:instructions|prompts|rules|constitution)\b"
        ),
    ),
    (
        "system_prompt_exfiltration",
        re.compile(
            r"(?i)\b(?:reveal|print|dump|output|show|leak)\s+(?:your\s+|the\s+)?(?:system\s+prompt|hidden\s+instructions|constitution|api\s+keys?|secrets?)\b"
        ),
    ),
    (
        "hitl_bypass_attempt",
        re.compile(
            r"(?i)\b(?:bypass|skip|disable|ignore)\s+(?:human\s+approval|hitl|guardrails?|security\s+checks?|policy)\b"
        ),
    ),
    (
        "destructive_shell_injection",
        re.compile(r"(?i)(?:;\s*rm\s+-rf\s+/|DROP\s+TABLE\s+|UNION\s+SELECT\s+)"),
    ),
)

_FORBIDDEN_SERVICE_TARGETS = frozenset({"*", "all", "production-all", "root", "cluster-wide"})


@dataclass
class SelfEvalResult:
    """Result of the post-generation self-evaluation guardrail."""

    passed: bool
    score: float
    findings: list[str] = field(default_factory=list)
    pii_redacted_count: int = 0


def detect_prompt_injection(text: str) -> tuple[bool, str | None]:
    """Detects prompt injection, jailbreak, or security-bypass patterns in text."""
    if not text:
        return False, None
    for rule_name, pattern in _INJECTION_PATTERNS:
        if pattern.search(text):
            return True, rule_name
    return False, None


def evaluate_model_response(
    text: str,
    *,
    redactor: PIIRedactor | None = None,
) -> tuple[SelfEvalResult, str]:
    """Self-evaluates an LLM response for PII/secret leakage and policy violations.

    Returns:
        Tuple of ``(SelfEvalResult, scrubbed_text)``.
    """
    active_redactor = redactor or get_default_redactor()
    findings: list[str] = []
    score = 1.0

    redaction_report = active_redactor.redact_with_report(text)
    scrubbed = redaction_report.redacted_text
    if redaction_report.redactions_count > 0:
        findings.append(
            f"Redacted {redaction_report.redactions_count} sensitive entity(ies) from model output: "
            f"{sorted(redaction_report.detected_types.keys())}"
        )
        score -= 0.25

    if re.search(r"(?i)\b(?:approval\s+bypassed|skipped\s+human\s+confirmation)\b", scrubbed):
        findings.append("Model output referenced bypassing human confirmation.")
        score -= 0.5

    if not scrubbed.strip():
        findings.append("Empty model output detected.")
        score = 0.0

    score = max(0.0, round(score, 2))
    passed = score >= 0.7 and not any("bypassing" in f for f in findings)
    return (
        SelfEvalResult(
            passed=passed,
            score=score,
            findings=findings,
            pii_redacted_count=redaction_report.redactions_count,
        ),
        scrubbed,
    )


class EnterprisePolicyGuardrailPlugin(BasePlugin):
    """ADK BasePlugin enforcing security guardrails, PII redaction, compaction, and HITL."""

    def __init__(
        self,
        *,
        name: str = "enterprise_policy_guardrail_plugin",
        hitl_gate: HumanApprovalGate | None = None,
        redactor: PIIRedactor | None = None,
        compactor: ContextCompactor | None = None,
        model_armor_template_id: str | None = None,
    ) -> None:
        super().__init__(name=name)
        self.hitl_gate = hitl_gate or get_default_hitl_gate()
        self.redactor = redactor or get_default_redactor()
        self.compactor = compactor or ContextCompactor(redactor=self.redactor)
        self.model_armor_template_id = model_armor_template_id or os.getenv(
            "MODEL_ARMOR_TEMPLATE_ID"
        )
        self.logger = get_logger("geap.guardrails.policy")
        self.last_self_eval: SelfEvalResult | None = None

    def _screen_with_model_armor(self, text: str) -> tuple[bool, str | None]:
        """Optional Google Cloud Model Armor hook when template ID is configured.

        Falls back seamlessly to deterministic local prompt-injection rules when
        Model Armor is not enabled in local/CI environments.
        """
        if self.model_armor_template_id and os.getenv("ENABLE_MODEL_ARMOR", "false").lower() in {
            "1",
            "true",
            "yes",
        }:
            try:  # pragma: no cover - requires live GCP Model Armor API
                from google.cloud import modelarmor_v1

                client = modelarmor_v1.ModelArmorClient()
                request = modelarmor_v1.SanitizeUserPromptRequest(
                    name=self.model_armor_template_id,
                    user_prompt_data=modelarmor_v1.DataItem(text=text),
                )
                result = client.sanitize_user_prompt(request=request)
                if str(result.sanitization_result.filter_match_state).endswith("MATCH_FOUND"):
                    return True, "google_cloud_model_armor"
            except Exception:
                pass
        return detect_prompt_injection(text)

    def _build_blocked_text(self, rule_name: str | None) -> str:
        return (
            "Request blocked by Enterprise Policy Guardrail "
            f"(rule='{rule_name}'). I cannot override operational "
            "safety rules, disclose system instructions/secrets, "
            "or bypass Human-in-the-Loop approvals. Please rephrase "
            "with a valid enterprise operations request."
        )

    async def before_run_callback(
        self, *, invocation_context: InvocationContext
    ) -> Optional[types.Content]:
        """Screens incoming user messages before any workflow stage executes."""
        user_content = getattr(invocation_context, "user_content", None)
        if user_content is None:
            return None
        with traced_operation(
            "guardrail.before_run",
            attributes={"adk.invocation_id": invocation_context.invocation_id},
        ) as span:
            user_text = extract_text_from_contents([user_content])
            blocked, rule_name = self._screen_with_model_armor(user_text)
            if blocked:
                span.set_attribute("guardrail.decision", "blocked")
                span.set_attribute("guardrail.rule", rule_name or "unknown")
                self.logger.warning(
                    "guardrail.before_run.blocked",
                    rule=rule_name,
                    invocation_id=invocation_context.invocation_id,
                )
                return types.Content(
                    role="model",
                    parts=[types.Part.from_text(text=self._build_blocked_text(rule_name))],
                )
            span.set_attribute("guardrail.decision", "allow")
            return None

    async def before_model_callback(
        self, *, callback_context: CallbackContext, llm_request: LlmRequest
    ) -> Optional[LlmResponse]:
        """Screens incoming prompts for injection, scrubs PII, and compacts history."""
        with traced_operation(
            "guardrail.before_model",
            attributes={"agent.name": getattr(callback_context, "agent_name", "unknown")},
        ) as span:
            combined_text = extract_text_from_contents(llm_request.contents)
            blocked, rule_name = self._screen_with_model_armor(combined_text)
            if blocked:
                span.set_attribute("guardrail.decision", "blocked")
                span.set_attribute("guardrail.rule", rule_name or "unknown")
                self.logger.warning(
                    "guardrail.before_model.blocked",
                    rule=rule_name,
                    agent_name=getattr(callback_context, "agent_name", "unknown"),
                )
                blocked_text = self._build_blocked_text(rule_name)
                response_schema = getattr(
                    getattr(llm_request, "config", None), "response_schema", None
                )
                if response_schema is IncidentTriageReport:
                    blocked_text = IncidentTriageReport(
                        incident_summary=blocked_text,
                        affected_service="policy-guardrail",
                        severity="P3",
                        sla_status="WITHIN_SLA",
                        root_cause_assessment=f"Blocked unsafe request (rule='{rule_name}').",
                        actions_taken=["Blocked request at Enterprise Policy Guardrail"],
                        pending_human_approvals=[],
                        recommended_next_steps=[
                            "Submit a valid enterprise operations request without policy overrides."
                        ],
                        confidence_score=1.0,
                    ).model_dump_json()
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part.from_text(text=blocked_text)],
                    )
                )

            # Actively scrub PII in user prompt parts prior to model call.
            total_redactions = 0
            for content in llm_request.contents or []:
                for part in content.parts or []:
                    if getattr(part, "text", None):
                        report = self.redactor.redact_with_report(part.text)
                        if report.redactions_count > 0:
                            part.text = report.redacted_text
                            total_redactions += report.redactions_count

            if total_redactions > 0:
                span.set_attribute("pii.redacted_count", total_redactions)
                self.logger.info(
                    "guardrail.before_model.pii_redacted",
                    redactions_count=total_redactions,
                )

            # Apply sliding-window compaction when token budget is exceeded.
            compaction = self.compactor.compact_llm_request(llm_request)
            if compaction.compacted:
                span.set_attribute("compaction.tokens_saved", compaction.tokens_saved)

            span.set_attribute("guardrail.decision", "allow")
            return None

    async def after_model_callback(
        self, *, callback_context: CallbackContext, llm_response: LlmResponse
    ) -> Optional[LlmResponse]:
        """Runs self-evaluation on model outputs and scrubs any residual PII."""
        with traced_operation(
            "guardrail.after_model.self_eval",
            attributes={"agent.name": getattr(callback_context, "agent_name", "unknown")},
        ) as span:
            if not llm_response.content or not llm_response.content.parts:
                return None

            modified = False
            for part in llm_response.content.parts:
                text = getattr(part, "text", None)
                if not text:
                    continue
                eval_result, scrubbed = evaluate_model_response(text, redactor=self.redactor)
                self.last_self_eval = eval_result
                span.set_attribute("self_eval.passed", eval_result.passed)
                span.set_attribute("self_eval.score", eval_result.score)
                if scrubbed != text:
                    part.text = scrubbed
                    modified = True
                if not eval_result.passed:
                    self.logger.warning(
                        "guardrail.after_model.self_eval_failed",
                        score=eval_result.score,
                        findings=eval_result.findings,
                    )
                    part.text = (
                        "Response revised by Enterprise Self-Evaluation Guardrail: "
                        "high-stakes operational actions require explicit human confirmation "
                        "and cannot be bypassed."
                    )
                    modified = True

            return llm_response if modified else None

    async def before_tool_callback(
        self,
        *,
        tool: BaseTool,
        tool_args: dict[str, Any],
        tool_context: ToolContext,
    ) -> Optional[dict[str, Any]]:
        """Enforces tool target policy and mandatory HITL approval for high-stakes tools."""
        with traced_operation(
            "guardrail.before_tool",
            attributes={"tool.name": tool.name},
        ) as span:
            service_name = str(tool_args.get("service_name", "")).strip().lower()
            if service_name in _FORBIDDEN_SERVICE_TARGETS:
                span.set_attribute("guardrail.decision", "blocked_by_policy")
                self.logger.warning(
                    "guardrail.before_tool.blocked_target",
                    tool_name=tool.name,
                    service_name=service_name,
                )
                return ToolErrorResponse(
                    error_code="POLICY_WILDCARD_TARGET_BLOCKED",
                    message=f"Target '{service_name}' is prohibited by enterprise blast-radius policy.",
                    invalid_fields=["service_name"],
                    recovery_instructions=(
                        "Specify a single canonical service name (for example 'payments-api' "
                        "or 'checkout-web') instead of wildcard or cluster-wide targets."
                    ),
                    retryable=True,
                    allowed_values={
                        "service_name": [
                            "payments-api",
                            "checkout-web",
                            "auth-gateway",
                            "orders-db",
                            "inventory-sync",
                        ]
                    },
                ).model_dump(mode="json")

            if self.hitl_gate.requires_approval(tool.name):
                approval_token = tool_args.get("approval_token")
                approved, _ = self.hitl_gate.verify_approval(
                    tool_name=tool.name,
                    approval_token=str(approval_token) if approval_token else None,
                    tool_context=tool_context,
                )
                if not approved:
                    span.set_attribute("guardrail.decision", "pending_human_approval")
                    pending = self.hitl_gate.request_approval(
                        tool_name=tool.name,
                        tool_args=tool_args,
                        tool_context=tool_context,
                    )
                    return pending.model_dump(mode="json")

            span.set_attribute("guardrail.decision", "allow")
            return None
