"""Secure secret retrieval via Google Cloud Secret Manager with local env fallback.

All sensitive credentials (API keys, database URLs, webhook signing tokens) are
resolved dynamically at runtime through Google Cloud Secret Manager when running
in GCP, or via environment variables in local development and CI. No secrets are
ever hardcoded in source control.
"""

from __future__ import annotations

import os
from functools import lru_cache
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class SecretResolutionError(RuntimeError):
    """Raised when a required secret cannot be resolved from Secret Manager or env."""


class SecretManagerProvider:
    """Fetches secrets from Google Cloud Secret Manager with safe env-var fallback.

    Resolution order for a secret:
    1. In-memory cache (when caching is enabled).
    2. Google Cloud Secret Manager (`projects/{project_id}/secrets/{secret_id}/versions/{version}`)
       when `project_id` is configured and `use_secret_manager=True`.
    3. Environment variable fallback (`env_var`) for local development and CI.
    4. Optional default value (only for non-sensitive settings such as local SQLite URLs).
    """

    def __init__(
        self,
        project_id: str | None = None,
        use_secret_manager: bool | None = None,
        client: Any | None = None,
    ) -> None:
        self.project_id = project_id or os.getenv("GCP_PROJECT_ID") or os.getenv("GOOGLE_CLOUD_PROJECT")
        if use_secret_manager is None:
            env_flag = os.getenv("USE_SECRET_MANAGER", "").strip().lower()
            self.use_secret_manager = env_flag in {"1", "true", "yes"} or bool(
                self.project_id and os.getenv("K_SERVICE")
            )
        else:
            self.use_secret_manager = use_secret_manager
        self._client = client
        self._cache: dict[tuple[str, str], str] = {}

    def _get_client(self) -> Any:
        """Lazily initializes the Google Cloud Secret Manager client."""
        if self._client is None:
            from google.cloud import secretmanager

            self._client = secretmanager.SecretManagerServiceClient()
        return self._client

    def build_resource_name(self, secret_id: str, version: str = "latest") -> str:
        """Constructs the canonical Secret Manager secret version resource path."""
        if not self.project_id:
            raise SecretResolutionError(
                "GCP_PROJECT_ID (or GOOGLE_CLOUD_PROJECT) must be set to access Secret Manager."
            )
        return f"projects/{self.project_id}/secrets/{secret_id}/versions/{version}"

    def get_secret(
        self,
        secret_id: str,
        *,
        env_var: str | None = None,
        version: str = "latest",
        default: str | None = None,
        required: bool = False,
    ) -> str | None:
        """Resolves a secret from Secret Manager or environment variables.

        Args:
            secret_id: Secret name in Google Cloud Secret Manager.
            env_var: Fallback environment variable name for local/CI runs.
            version: Secret version identifier (defaults to ``latest``).
            default: Non-sensitive fallback value if neither source provides one.
            required: When True, raises ``SecretResolutionError`` if unresolved.

        Returns:
            The resolved secret string, or ``None`` if optional and unset.
        """
        cache_key = (secret_id, version)
        if cache_key in self._cache:
            return self._cache[cache_key]

        if self.use_secret_manager and self.project_id:
            try:
                client = self._get_client()
                name = self.build_resource_name(secret_id, version=version)
                response = client.access_secret_version(request={"name": name})
                value = response.payload.data.decode("utf-8").strip()
                if value:
                    self._cache[cache_key] = value
                    return value
            except Exception as exc:  # pragma: no cover - fallback path exercised in tests
                if env_var and os.getenv(env_var):
                    pass
                elif required and default is None:
                    raise SecretResolutionError(
                        f"Failed to fetch secret '{secret_id}' from Secret Manager: {exc}"
                    ) from exc

        if env_var:
            env_val = os.getenv(env_var)
            if env_val is not None and env_val.strip() != "":
                return env_val.strip()

        if default is not None:
            return default

        if required:
            raise SecretResolutionError(
                f"Required secret '{secret_id}' (env fallback '{env_var}') is not configured."
            )
        return None

    def clear_cache(self) -> None:
        """Clears the in-memory secret cache to force fresh Secret Manager reads."""
        self._cache.clear()


class AppSettings(BaseModel):
    """Runtime application configuration hydrated via Secret Manager and env vars."""

    model_config = ConfigDict(extra="forbid")

    app_name: str = Field(default="geap_enterprise_ops_agent")
    environment: str = Field(default="dev")
    gcp_project_id: str | None = Field(default=None)
    gcp_region: str = Field(default="us-central1")
    flash_model: str = Field(default="gemini-2.5-flash")
    pro_model: str = Field(default="gemini-2.5-pro")
    session_db_url: str = Field(default="sqlite+aiosqlite:///./data/ops_sessions.db")
    knowledge_db_path: str = Field(default="./data/ops_knowledge.db")
    memory_db_path: str = Field(default="./data/ops_memory.db")
    agent_engine_id: str | None = Field(default=None)
    vertex_ai_datastore_id: str | None = Field(default=None)
    model_armor_template_id: str | None = Field(default=None)
    enable_cloud_dlp: bool = Field(default=False)
    enable_otel_cloud_export: bool = Field(default=False)
    otlp_endpoint: str | None = Field(default=None)
    secret_gemini_api_key_id: str = Field(default="gemini-api-key")
    secret_ops_db_url_id: str = Field(default="ops-db-url")
    secret_pagerduty_token_id: str = Field(default="pagerduty-webhook-secret")
    compaction_token_threshold: int = Field(default=4000, ge=256)
    compaction_interval: int = Field(default=5, ge=1)
    compaction_overlap_size: int = Field(default=1, ge=0)
    compaction_retention_size: int = Field(default=2, ge=1)

    def load_runtime_secrets(
        self, provider: SecretManagerProvider | None = None
    ) -> dict[str, str | None]:
        """Resolves sensitive credentials on demand without storing them in repr/logs."""
        secret_provider = provider or SecretManagerProvider(project_id=self.gcp_project_id)
        return {
            "google_api_key": secret_provider.get_secret(
                self.secret_gemini_api_key_id,
                env_var="GOOGLE_API_KEY",
                required=False,
            ),
            "ops_database_url": secret_provider.get_secret(
                self.secret_ops_db_url_id,
                env_var="OPS_DATABASE_URL",
                default=self.session_db_url,
                required=False,
            ),
            "pagerduty_webhook_secret": secret_provider.get_secret(
                self.secret_pagerduty_token_id,
                env_var="PAGERDUTY_WEBHOOK_SECRET",
                required=False,
            ),
        }


@lru_cache(maxsize=1)
def get_settings() -> AppSettings:
    """Returns cached application settings populated from environment configuration."""
    return AppSettings(
        app_name=os.getenv("ADK_APP_NAME", "geap_enterprise_ops_agent"),
        environment=os.getenv("APP_ENV", "dev"),
        gcp_project_id=os.getenv("GCP_PROJECT_ID") or os.getenv("GOOGLE_CLOUD_PROJECT"),
        gcp_region=os.getenv("GCP_REGION") or os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1"),
        flash_model=os.getenv("ADK_FLASH_MODEL", "gemini-2.5-flash"),
        pro_model=os.getenv("ADK_PRO_MODEL", "gemini-2.5-pro"),
        session_db_url=os.getenv("OPS_DATABASE_URL", "sqlite+aiosqlite:///./data/ops_sessions.db"),
        knowledge_db_path=os.getenv("OPS_KNOWLEDGE_DB_PATH", "./data/ops_knowledge.db"),
        memory_db_path=os.getenv("OPS_MEMORY_DB_PATH", "./data/ops_memory.db"),
        agent_engine_id=os.getenv("AGENT_ENGINE_ID"),
        vertex_ai_datastore_id=os.getenv("VERTEX_AI_DATASTORE_ID"),
        model_armor_template_id=os.getenv("MODEL_ARMOR_TEMPLATE_ID"),
        enable_cloud_dlp=os.getenv("ENABLE_CLOUD_DLP", "false").lower() in {"1", "true", "yes"},
        enable_otel_cloud_export=os.getenv("ENABLE_OTEL_CLOUD_EXPORT", "false").lower()
        in {"1", "true", "yes"},
        otlp_endpoint=os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT"),
        secret_gemini_api_key_id=os.getenv("SECRET_GEMINI_API_KEY_ID", "gemini-api-key"),
        secret_ops_db_url_id=os.getenv("SECRET_OPS_DB_URL_ID", "ops-db-url"),
        secret_pagerduty_token_id=os.getenv(
            "SECRET_PAGERDUTY_TOKEN_ID", "pagerduty-webhook-secret"
        ),
    )
