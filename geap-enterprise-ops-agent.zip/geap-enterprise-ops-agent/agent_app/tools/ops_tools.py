"""Enterprise Operations tools with strict Pydantic schemas, rich docstrings, and guided errors.

Every tool in this module adheres to four core AgentOps design principles:
1. **Descriptive Naming**: Explicit verb-noun names (`fetch_service_health_metrics`,
   `search_incident_runbooks`, `create_critical_incident_ticket`,
   `execute_production_service_rollback`, `schedule_maintenance_window`).
2. **Comprehensive Docstrings**: Clear purpose, usage boundaries, parameter rules,
   return payload structure, and error recovery behavior.
3. **Explicit JSON Schemas**: Validated via strict Pydantic v2 input/output models
   and exposed through ``SchemaValidatedFunctionTool``.
4. **Guided Error Handling**: Never crashes the agent loop on invalid arguments or
   missing prerequisites; returns structured ``ToolErrorResponse`` payloads with
   explicit ``recovery_instructions`` and ``allowed_values``.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Annotated, Any, Callable, Literal

from google.adk.tools import FunctionTool, ToolContext
from pydantic import BaseModel, Field, ValidationError

from agent_app.guardrails.hitl import get_default_hitl_gate
from agent_app.memory.session_store import get_default_knowledge_store
from agent_app.observability.logging_config import get_logger
from agent_app.observability.pii_redactor import get_default_redactor
from agent_app.observability.tracing import traced_operation
from agent_app.schemas import (
    CriticalIncidentRequest,
    CriticalIncidentResult,
    MaintenanceWindowRequest,
    MaintenanceWindowResult,
    ProductionRollbackRequest,
    ProductionRollbackResult,
    RunbookMatch,
    RunbookSearchQuery,
    RunbookSearchResult,
    ServiceHealthQuery,
    ServiceHealthResult,
    ToolErrorResponse,
)

logger = get_logger("geap.tools.ops")

# Deterministic enterprise service catalog simulating live telemetry endpoints.
SERVICE_TELEMETRY_CATALOG: dict[str, dict[str, Any]] = {
    "payments-api": {
        "oncall_team": "payments-sre@enterprise.example",
        "sla_target_pct": 99.95,
        "environments": {
            "prod": {
                "health_state": "CRITICAL",
                "availability_pct": 98.42,
                "p99_latency_ms": 1480,
                "error_rate_pct": 6.3,
                "active_version": "v2.15.0",
                "last_good_version": "v2.14.2",
                "recent_alerts": [
                    "ALERT-901: Elevated HTTP 503 rate (>5%) on /v2/charges",
                    "ALERT-904: PostgreSQL connection pool saturation at 98%",
                ],
            },
            "staging": {
                "health_state": "HEALTHY",
                "availability_pct": 99.99,
                "p99_latency_ms": 145,
                "error_rate_pct": 0.05,
                "active_version": "v2.15.1-rc1",
                "last_good_version": "v2.14.2",
                "recent_alerts": [],
            },
            "dev": {
                "health_state": "HEALTHY",
                "availability_pct": 99.95,
                "p99_latency_ms": 180,
                "error_rate_pct": 0.1,
                "active_version": "v2.15.1-dev",
                "last_good_version": "v2.14.2",
                "recent_alerts": [],
            },
        },
    },
    "checkout-web": {
        "oncall_team": "checkout-sre@enterprise.example",
        "sla_target_pct": 99.90,
        "environments": {
            "prod": {
                "health_state": "DEGRADED",
                "availability_pct": 99.72,
                "p99_latency_ms": 740,
                "error_rate_pct": 1.8,
                "active_version": "v4.8.3",
                "last_good_version": "v4.8.2",
                "recent_alerts": [
                    "ALERT-812: Checkout p99 latency exceeded 600ms threshold",
                ],
            },
            "staging": {
                "health_state": "HEALTHY",
                "availability_pct": 99.98,
                "p99_latency_ms": 190,
                "error_rate_pct": 0.1,
                "active_version": "v4.8.4-rc1",
                "last_good_version": "v4.8.2",
                "recent_alerts": [],
            },
            "dev": {
                "health_state": "HEALTHY",
                "availability_pct": 99.95,
                "p99_latency_ms": 210,
                "error_rate_pct": 0.15,
                "active_version": "v4.8.4-dev",
                "last_good_version": "v4.8.2",
                "recent_alerts": [],
            },
        },
    },
    "auth-gateway": {
        "oncall_team": "identity-sre@enterprise.example",
        "sla_target_pct": 99.99,
        "environments": {
            "prod": {
                "health_state": "CRITICAL",
                "availability_pct": 98.90,
                "p99_latency_ms": 920,
                "error_rate_pct": 5.1,
                "active_version": "v3.4.0",
                "last_good_version": "v3.3.9",
                "recent_alerts": [
                    "ALERT-771: Spike in HTTP 401 JWT signature verification errors",
                ],
            },
            "staging": {
                "health_state": "HEALTHY",
                "availability_pct": 99.99,
                "p99_latency_ms": 85,
                "error_rate_pct": 0.02,
                "active_version": "v3.4.0",
                "last_good_version": "v3.3.9",
                "recent_alerts": [],
            },
            "dev": {
                "health_state": "HEALTHY",
                "availability_pct": 99.98,
                "p99_latency_ms": 95,
                "error_rate_pct": 0.05,
                "active_version": "v3.4.1-dev",
                "last_good_version": "v3.3.9",
                "recent_alerts": [],
            },
        },
    },
    "orders-db": {
        "oncall_team": "data-platform-sre@enterprise.example",
        "sla_target_pct": 99.95,
        "environments": {
            "prod": {
                "health_state": "DEGRADED",
                "availability_pct": 99.85,
                "p99_latency_ms": 860,
                "error_rate_pct": 1.6,
                "active_version": "v16.4.1",
                "last_good_version": "v16.4.0",
                "recent_alerts": [
                    "ALERT-615: Primary-to-replica replication lag reached 14.2 seconds",
                ],
            },
            "staging": {
                "health_state": "HEALTHY",
                "availability_pct": 99.99,
                "p99_latency_ms": 42,
                "error_rate_pct": 0.01,
                "active_version": "v16.4.1",
                "last_good_version": "v16.4.0",
                "recent_alerts": [],
            },
            "dev": {
                "health_state": "HEALTHY",
                "availability_pct": 99.99,
                "p99_latency_ms": 50,
                "error_rate_pct": 0.01,
                "active_version": "v16.4.1",
                "last_good_version": "v16.4.0",
                "recent_alerts": [],
            },
        },
    },
    "inventory-sync": {
        "oncall_team": "supply-chain-sre@enterprise.example",
        "sla_target_pct": 99.50,
        "environments": {
            "prod": {
                "health_state": "HEALTHY",
                "availability_pct": 99.92,
                "p99_latency_ms": 230,
                "error_rate_pct": 0.25,
                "active_version": "v1.12.0",
                "last_good_version": "v1.11.8",
                "recent_alerts": [
                    "WARN-302: Pub/Sub backlog slightly elevated (1,450 messages)",
                ],
            },
            "staging": {
                "health_state": "HEALTHY",
                "availability_pct": 99.99,
                "p99_latency_ms": 120,
                "error_rate_pct": 0.05,
                "active_version": "v1.12.0",
                "last_good_version": "v1.11.8",
                "recent_alerts": [],
            },
            "dev": {
                "health_state": "HEALTHY",
                "availability_pct": 99.98,
                "p99_latency_ms": 130,
                "error_rate_pct": 0.05,
                "active_version": "v1.12.1-dev",
                "last_good_version": "v1.11.8",
                "recent_alerts": [],
            },
        },
    },
}

_SLA_RESPONSE_MINUTES = {"P0": 15, "P1": 30, "P2": 120, "P3": 480}


def _get_mutable_state(tool_context: ToolContext | None) -> Any | None:
    """Returns mutable ADK ``State`` or plain ``dict`` when available on ``tool_context``."""
    if tool_context is None:
        return None
    state = getattr(tool_context, "state", None)
    if state is not None and hasattr(state, "__setitem__"):
        return state
    return None


def _format_validation_error(
    exc: ValidationError,
    *,
    tool_name: str,
    recovery_hint: str,
    allowed_values: dict[str, list[str]] | None = None,
) -> dict[str, Any]:
    """Converts a Pydantic ValidationError into a guided ``ToolErrorResponse`` dict."""
    invalid_fields = [
        ".".join(str(loc) for loc in err.get("loc", [])) or "input"
        for err in exc.errors()
    ]
    details = "; ".join(
        f"{'.'.join(str(x) for x in err.get('loc', []))}: {err.get('msg')}"
        for err in exc.errors()
    )
    return ToolErrorResponse(
        error_code="SCHEMA_VALIDATION_ERROR",
        message=f"Invalid input arguments for '{tool_name}': {details}",
        invalid_fields=invalid_fields,
        recovery_instructions=recovery_hint,
        retryable=True,
        allowed_values=allowed_values or {},
    ).model_dump(mode="json")


class SchemaValidatedFunctionTool(FunctionTool):
    """ADK FunctionTool subclass explicitly exposing Pydantic input & output JSON schemas."""

    def __init__(
        self,
        func: Callable[..., Any],
        *,
        input_schema: type[BaseModel],
        output_schema: type[BaseModel],
        require_confirmation: bool = False,
    ) -> None:
        super().__init__(func, require_confirmation=require_confirmation)
        self.input_schema = input_schema
        self.output_schema = output_schema

    def get_json_schemas(self) -> dict[str, dict[str, Any]]:
        """Returns explicit JSON Schema definitions for both input and output contracts."""
        return {
            "input_schema": self.input_schema.model_json_schema(),
            "output_schema": self.output_schema.model_json_schema(),
        }


def fetch_service_health_metrics(
    service_name: Annotated[
        str,
        Field(
            description=(
                "Canonical lowercase kebab-case service name to inspect "
                "(e.g., 'payments-api', 'checkout-web', 'auth-gateway', 'orders-db', 'inventory-sync')."
            )
        ),
    ],
    environment: Annotated[
        Literal["prod", "staging", "dev"],
        Field(description="Target deployment environment ('prod', 'staging', or 'dev')."),
    ] = "prod",
    window_minutes: Annotated[
        int,
        Field(
            ge=1,
            le=1440,
            description="Telemetry lookback window in minutes, between 1 and 1440.",
        ),
    ] = 15,
    tool_context: ToolContext | None = None,
) -> dict[str, Any]:
    """Fetch real-time availability, latency, error-rate, and SLA metrics for a service.

    Use this read-only diagnostic tool at the start of every incident triage workflow to
    gather ground-truth telemetry before classifying severity or proposing remediation.
    Do NOT guess metrics or version tags without calling this tool first.

    Args:
        service_name: Canonical lowercase kebab-case service identifier registered in
            the enterprise service catalog (e.g., ``payments-api``).
        environment: Deployment environment to query (``prod``, ``staging``, or ``dev``).
            Defaults to ``prod``.
        window_minutes: Lookback window in minutes (integer from 1 to 1440). Defaults to 15.
        tool_context: Optional Google ADK ``ToolContext`` injected automatically at runtime.

    Returns:
        A JSON dictionary matching ``ServiceHealthResult`` containing ``health_state``,
        ``availability_pct``, ``sla_target_pct``, ``sla_breached``, ``p99_latency_ms``,
        ``error_rate_pct``, ``active_version``, ``last_good_version``, and ``recent_alerts``.
        On invalid input or unknown service, returns a structured ``ToolErrorResponse``
        with ``allowed_values`` and ``recovery_instructions`` instead of raising an error.
    """
    with traced_operation(
        "tool.fetch_service_health_metrics",
        attributes={"service.name": str(service_name), "environment": str(environment)},
    ):
        try:
            query = ServiceHealthQuery(
                service_name=service_name,
                environment=environment,
                window_minutes=window_minutes,
            )
        except ValidationError as exc:
            return _format_validation_error(
                exc,
                tool_name="fetch_service_health_metrics",
                recovery_hint=(
                    "Fix the invalid parameters and retry `fetch_service_health_metrics`. "
                    "Ensure `service_name` is lowercase kebab-case from `allowed_values`, "
                    "`environment` is one of ['prod', 'staging', 'dev'], and "
                    "`window_minutes` is between 1 and 1440."
                ),
                allowed_values={
                    "service_name": sorted(SERVICE_TELEMETRY_CATALOG.keys()),
                    "environment": ["prod", "staging", "dev"],
                },
            )

        service_entry = SERVICE_TELEMETRY_CATALOG.get(query.service_name)
        if service_entry is None:
            return ToolErrorResponse(
                error_code="UNKNOWN_SERVICE",
                message=f"Service '{query.service_name}' was not found in the enterprise catalog.",
                invalid_fields=["service_name"],
                recovery_instructions=(
                    "Select a valid service identifier from `allowed_values.service_name` "
                    "and call `fetch_service_health_metrics` again. If the user mentioned a "
                    "symptom rather than an exact service name, call `search_incident_runbooks` "
                    "first to map the symptom to a known service."
                ),
                retryable=True,
                suggested_next_tool="search_incident_runbooks",
                allowed_values={"service_name": sorted(SERVICE_TELEMETRY_CATALOG.keys())},
            ).model_dump(mode="json")

        metrics = service_entry["environments"][query.environment]
        sla_target = float(service_entry["sla_target_pct"])
        availability = float(metrics["availability_pct"])
        result = ServiceHealthResult(
            service_name=query.service_name,
            environment=query.environment,
            window_minutes=query.window_minutes,
            health_state=metrics["health_state"],
            availability_pct=availability,
            sla_target_pct=sla_target,
            sla_breached=availability < sla_target,
            p99_latency_ms=int(metrics["p99_latency_ms"]),
            error_rate_pct=float(metrics["error_rate_pct"]),
            active_version=str(metrics["active_version"]),
            last_good_version=str(metrics["last_good_version"]),
            recent_alerts=list(metrics["recent_alerts"]),
        )

        state = _get_mutable_state(tool_context)
        if state is not None:
            state["last_service_health"] = result.model_dump(mode="json")
            if result.health_state == "CRITICAL":
                state["incident_severity"] = "P0"
            elif result.health_state == "DEGRADED":
                state["incident_severity"] = "P1"

        return result.model_dump(mode="json")


def search_incident_runbooks(
    query: Annotated[
        str,
        Field(
            min_length=3,
            max_length=300,
            description="Incident symptoms, error codes, or operational keywords (3-300 chars).",
        ),
    ],
    service_name: Annotated[
        str | None,
        Field(
            description="Optional canonical service name to narrow runbook retrieval."
        ),
    ] = None,
    top_k: Annotated[
        int,
        Field(
            ge=1,
            le=10,
            description="Maximum number of ranked runbook matches to return (1 to 10).",
        ),
    ] = 3,
    tool_context: ToolContext | None = None,
) -> dict[str, Any]:
    """Search the persistent enterprise runbook database for verified remediation playbooks.

    Queries the SQLite-backed TF-IDF vector knowledge store to retrieve ranked SRE
    runbooks matching observed symptoms and optional service filters. Always call this
    tool before recommending remediation procedures so steps remain grounded in approved
    operational runbooks.

    Args:
        query: Natural-language symptom description or alert keywords (e.g.,
            ``payments 503 connection pool saturation``).
        service_name: Optional lowercase kebab-case service filter (e.g., ``payments-api``).
        top_k: Maximum number of ranked runbooks to return (1 to 10). Defaults to 3.
        tool_context: Optional Google ADK ``ToolContext`` injected automatically at runtime.

    Returns:
        A JSON dictionary matching ``RunbookSearchResult`` containing ``total_matches``
        and ranked ``runbooks`` (each with ``runbook_id``, ``title``, ``relevance_score``,
        ``recommended_steps``, and ``requires_human_approval``). Returns a structured
        ``ToolErrorResponse`` with recovery instructions if validation fails or no match
        is found for a filtered service.
    """
    with traced_operation(
        "tool.search_incident_runbooks",
        attributes={"service.name": str(service_name or "all")},
    ):
        try:
            validated = RunbookSearchQuery(
                query=query,
                service_name=service_name,
                top_k=top_k,
            )
        except ValidationError as exc:
            return _format_validation_error(
                exc,
                tool_name="search_incident_runbooks",
                recovery_hint=(
                    "Provide a descriptive `query` between 3 and 300 characters and a "
                    "`top_k` integer between 1 and 10, then retry `search_incident_runbooks`."
                ),
            )

        store = get_default_knowledge_store()
        matches = store.search_runbooks(
            validated.query,
            service_name=validated.service_name,
            top_k=validated.top_k,
        )

        if not matches and validated.service_name:
            return ToolErrorResponse(
                error_code="NO_RUNBOOKS_FOR_SERVICE",
                message=(
                    f"No runbooks matched service '{validated.service_name}' for query "
                    f"'{validated.query}'."
                ),
                invalid_fields=["service_name"],
                recovery_instructions=(
                    "Retry `search_incident_runbooks` with `service_name=None` to search "
                    "across all enterprise runbooks, or pick a valid service name from "
                    "`allowed_values.service_name`."
                ),
                retryable=True,
                suggested_next_tool="search_incident_runbooks",
                allowed_values={"service_name": sorted(SERVICE_TELEMETRY_CATALOG.keys())},
            ).model_dump(mode="json")

        result = RunbookSearchResult(
            query=validated.query,
            total_matches=len(matches),
            runbooks=[RunbookMatch(**item) for item in matches],
        )
        state = _get_mutable_state(tool_context)
        if state is not None:
            state["matched_runbooks"] = [rb.runbook_id for rb in result.runbooks]
        return result.model_dump(mode="json")


def create_critical_incident_ticket(
    service_name: Annotated[
        str,
        Field(description="Affected canonical service name (e.g., 'payments-api')."),
    ],
    severity: Annotated[
        Literal["P0", "P1", "P2", "P3"],
        Field(description="Enterprise incident severity tier ('P0', 'P1', 'P2', or 'P3')."),
    ],
    summary: Annotated[
        str,
        Field(
            min_length=10,
            max_length=240,
            description="Concise PII-free incident headline (10-240 chars).",
        ),
    ],
    root_cause_hypothesis: Annotated[
        str,
        Field(
            min_length=10,
            max_length=1000,
            description="Evidence-backed root cause hypothesis referencing telemetry/runbooks.",
        ),
    ],
    runbook_id: Annotated[
        str | None,
        Field(description="Optional authoritative runbook ID (e.g., 'RB-PAY-001')."),
    ] = None,
    tool_context: ToolContext | None = None,
) -> dict[str, Any]:
    """Create and persist a structured incident ticket and page the owning on-call team.

    Persists a PII-scrubbed incident record into the durable SQLite incident ledger and
    computes the required SLA response time based on the enterprise severity matrix.
    Call this tool BEFORE proposing a production rollback so the rollback has a valid
    linked ``incident_ticket_id``.

    Args:
        service_name: Canonical lowercase kebab-case service name experiencing the incident.
        severity: Assessed severity level (``P0``, ``P1``, ``P2``, or ``P3``).
        summary: Concise, PII-free incident headline (10-240 characters).
        root_cause_hypothesis: Telemetry-grounded hypothesis (10-1000 characters).
        runbook_id: Optional runbook ID obtained from ``search_incident_runbooks``.
        tool_context: Optional Google ADK ``ToolContext`` injected automatically at runtime.

    Returns:
        A JSON dictionary matching ``CriticalIncidentResult`` containing ``ticket_id``
        (format ``INC-XXXXX``), ``assigned_oncall_team``, ``sla_response_minutes``, and
        ``created_at_utc``. Returns a guided ``ToolErrorResponse`` if inputs are invalid.
    """
    with traced_operation(
        "tool.create_critical_incident_ticket",
        attributes={"service.name": str(service_name), "incident.severity": str(severity)},
    ):
        redactor = get_default_redactor()
        try:
            req = CriticalIncidentRequest(
                service_name=service_name,
                severity=severity,
                summary=redactor.redact_text(summary),
                root_cause_hypothesis=redactor.redact_text(root_cause_hypothesis),
                runbook_id=runbook_id,
            )
        except ValidationError as exc:
            return _format_validation_error(
                exc,
                tool_name="create_critical_incident_ticket",
                recovery_hint=(
                    "Correct the highlighted fields and retry `create_critical_incident_ticket`. "
                    "Provide a valid service name, severity in ['P0', 'P1', 'P2', 'P3'], "
                    "and descriptive summary/hypothesis of at least 10 characters."
                ),
                allowed_values={
                    "service_name": sorted(SERVICE_TELEMETRY_CATALOG.keys()),
                    "severity": ["P0", "P1", "P2", "P3"],
                },
            )

        service_entry = SERVICE_TELEMETRY_CATALOG.get(req.service_name)
        if service_entry is None:
            return ToolErrorResponse(
                error_code="UNKNOWN_SERVICE",
                message=f"Cannot open incident ticket for unregistered service '{req.service_name}'.",
                invalid_fields=["service_name"],
                recovery_instructions=(
                    "Call `fetch_service_health_metrics` with a valid service from "
                    "`allowed_values.service_name`, then re-run `create_critical_incident_ticket`."
                ),
                retryable=True,
                suggested_next_tool="fetch_service_health_metrics",
                allowed_values={"service_name": sorted(SERVICE_TELEMETRY_CATALOG.keys())},
            ).model_dump(mode="json")

        ticket_id = f"INC-{uuid.uuid4().int % 90000 + 10000}"
        created_at = datetime.now(timezone.utc).isoformat()
        sla_minutes = _SLA_RESPONSE_MINUTES[req.severity]

        result = CriticalIncidentResult(
            ticket_id=ticket_id,
            service_name=req.service_name,
            severity=req.severity,
            summary=req.summary,
            assigned_oncall_team=str(service_entry["oncall_team"]),
            sla_response_minutes=sla_minutes,
            created_at_utc=created_at,
        )

        store = get_default_knowledge_store()
        store.save_incident_ticket(
            {
                **result.model_dump(mode="json"),
                "root_cause_hypothesis": req.root_cause_hypothesis,
                "runbook_id": req.runbook_id,
            }
        )

        state = _get_mutable_state(tool_context)
        if state is not None:
            state["active_incident_ticket_id"] = ticket_id
            state["incident_severity"] = req.severity

        logger.info(
            "incident.ticket.created",
            ticket_id=ticket_id,
            service_name=req.service_name,
            severity=req.severity,
            sla_response_minutes=sla_minutes,
        )
        return result.model_dump(mode="json")


def execute_production_service_rollback(
    service_name: Annotated[
        str,
        Field(description="Target production service to roll back (e.g., 'payments-api')."),
    ],
    target_version: Annotated[
        str,
        Field(description="Known-good semantic version tag to restore (e.g., 'v2.14.2')."),
    ],
    incident_ticket_id: Annotated[
        str,
        Field(
            pattern=r"^INC-\d{4,8}$",
            description="Linked incident ticket ID created prior to rollback (e.g., 'INC-48210').",
        ),
    ],
    reason: Annotated[
        str,
        Field(
            min_length=10,
            max_length=500,
            description="Audit justification explaining why rolling back restores service health.",
        ),
    ],
    approval_token: Annotated[
        str | None,
        Field(
            description=(
                "Optional verified human approval token from the HITL gate. Omit on initial "
                "proposal so the HITL hook pauses cleanly and requests human confirmation."
            )
        ),
    ] = None,
    tool_context: ToolContext | None = None,
) -> dict[str, Any]:
    """Roll back a live production service to a verified prior release (HITL-gated).

    HIGH-STAKES PRODUCTION MUTATION: This tool enforces an explicit Human-in-the-Loop
    (HITL) stop. If invoked without a verified human confirmation (either via ADK's
    ``tool_context.tool_confirmation`` or a granted ``approval_token``), execution pauses
    immediately and returns ``PendingApprovalResponse`` with an ``approval_id`` and
    operator instructions. Never attempt to fabricate or bypass human confirmation.

    Args:
        service_name: Canonical lowercase kebab-case service name to roll back.
        target_version: Known-good semantic version (must differ from broken ``active_version``).
        incident_ticket_id: Existing incident ticket ID matching ``INC-\\d{4,8}``.
        reason: Audit justification referencing observed metrics and runbook ID (10-500 chars).
        approval_token: Verified human confirmation ID granted after HITL review.
        tool_context: Optional Google ADK ``ToolContext`` injected automatically at runtime.

    Returns:
        - ``PendingApprovalResponse`` JSON dict if human approval has not yet been granted.
        - ``ProductionRollbackResult`` JSON dict once approved and executed.
        - ``ToolErrorResponse`` JSON dict with step-by-step recovery guidance on invalid
          arguments, unknown service, or rolling back to the currently active version.
    """
    with traced_operation(
        "tool.execute_production_service_rollback",
        attributes={"service.name": str(service_name), "hitl.required": True},
    ):
        try:
            req = ProductionRollbackRequest(
                service_name=service_name,
                target_version=target_version,
                incident_ticket_id=incident_ticket_id,
                reason=get_default_redactor().redact_text(reason),
                approval_token=approval_token,
            )
        except ValidationError as exc:
            return _format_validation_error(
                exc,
                tool_name="execute_production_service_rollback",
                recovery_hint=(
                    "Ensure `incident_ticket_id` matches 'INC-12345' (call "
                    "`create_critical_incident_ticket` first if you do not have one), "
                    "`target_version` is valid SemVer (e.g., 'v2.14.2'), and `reason` is "
                    "at least 10 characters before retrying."
                ),
                allowed_values={"service_name": sorted(SERVICE_TELEMETRY_CATALOG.keys())},
            )

        service_entry = SERVICE_TELEMETRY_CATALOG.get(req.service_name)
        if service_entry is None:
            return ToolErrorResponse(
                error_code="UNKNOWN_SERVICE",
                message=f"Service '{req.service_name}' does not exist in production catalog.",
                invalid_fields=["service_name"],
                recovery_instructions=(
                    "Call `fetch_service_health_metrics` with a valid service name from "
                    "`allowed_values.service_name` to identify the right service and its "
                    "`last_good_version`."
                ),
                retryable=True,
                suggested_next_tool="fetch_service_health_metrics",
                allowed_values={"service_name": sorted(SERVICE_TELEMETRY_CATALOG.keys())},
            ).model_dump(mode="json")

        prod_metrics = service_entry["environments"]["prod"]
        active_version = str(prod_metrics["active_version"])
        last_good_version = str(prod_metrics["last_good_version"])

        if req.target_version == active_version:
            return ToolErrorResponse(
                error_code="INVALID_ROLLBACK_TARGET",
                message=(
                    f"target_version '{req.target_version}' is identical to the currently "
                    f"running version '{active_version}' on '{req.service_name}'."
                ),
                invalid_fields=["target_version"],
                recovery_instructions=(
                    f"Call `fetch_service_health_metrics(service_name='{req.service_name}')` "
                    f"and set `target_version` to the verified `last_good_version` "
                    f"('{last_good_version}') instead."
                ),
                retryable=True,
                suggested_next_tool="fetch_service_health_metrics",
                allowed_values={"target_version": [last_good_version]},
            ).model_dump(mode="json")

        # Mandatory Human-in-the-Loop confirmation check.
        gate = get_default_hitl_gate()
        approved, approver_id = gate.verify_approval(
            tool_name="execute_production_service_rollback",
            approval_token=req.approval_token,
            tool_context=tool_context,
        )
        if not approved:
            pending = gate.request_approval(
                tool_name="execute_production_service_rollback",
                tool_args=req.model_dump(mode="json"),
                tool_context=tool_context,
            )
            return pending.model_dump(mode="json")

        rollback_id = f"RBK-{uuid.uuid4().hex[:8].upper()}"
        completed_at = datetime.now(timezone.utc).isoformat()
        result = ProductionRollbackResult(
            rollback_id=rollback_id,
            service_name=req.service_name,
            previous_version=active_version,
            restored_version=req.target_version,
            incident_ticket_id=req.incident_ticket_id,
            approved_by=approver_id or "verified-human-operator",
            completed_at_utc=completed_at,
        )

        get_default_knowledge_store().record_audit_action(
            action_id=rollback_id,
            action_type="production_rollback",
            service_name=req.service_name,
            payload=result.model_dump(mode="json"),
            approved_by=result.approved_by,
        )
        logger.info(
            "production.rollback.completed",
            rollback_id=rollback_id,
            service_name=req.service_name,
            restored_version=req.target_version,
            incident_ticket_id=req.incident_ticket_id,
        )
        return result.model_dump(mode="json")


def schedule_maintenance_window(
    service_name: Annotated[
        str,
        Field(description="Canonical service name requiring scheduled maintenance."),
    ],
    start_time_utc: Annotated[
        str,
        Field(
            pattern=r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?Z$",
            description="ISO-8601 UTC start time (e.g., '2026-11-21T02:00:00Z').",
        ),
    ],
    duration_minutes: Annotated[
        int,
        Field(
            ge=15,
            le=240,
            description="Maintenance window duration in minutes (15 to 240).",
        ),
    ],
    change_summary: Annotated[
        str,
        Field(
            min_length=10,
            max_length=500,
            description="Detailed summary of maintenance steps and rollback criteria.",
        ),
    ],
    approval_token: Annotated[
        str | None,
        Field(
            description="Optional verified human approval token obtained from the HITL gate."
        ),
    ] = None,
    tool_context: ToolContext | None = None,
) -> dict[str, Any]:
    """Schedule a customer-visible maintenance window for a production service (HITL-gated).

    HIGH-STAKES CHANGE MANAGEMENT ACTION: Enforces Human-in-the-Loop confirmation before
    booking downtime or notifying customer status channels. When called without a valid
    approval, pauses cleanly and returns ``PendingApprovalResponse`` with an ``approval_id``.

    Args:
        service_name: Canonical lowercase kebab-case service name (e.g., ``orders-db``).
        start_time_utc: Strict ISO-8601 UTC timestamp ending in ``Z``.
        duration_minutes: Duration between 15 and 240 minutes.
        change_summary: PII-free description of planned maintenance and backout plan.
        approval_token: Verified human confirmation ID granted after HITL review.
        tool_context: Optional Google ADK ``ToolContext`` injected automatically at runtime.

    Returns:
        - ``PendingApprovalResponse`` JSON dict awaiting human approval.
        - ``MaintenanceWindowResult`` JSON dict once approved and booked.
        - ``ToolErrorResponse`` JSON dict with recovery guidance on schema/catalog errors.
    """
    with traced_operation(
        "tool.schedule_maintenance_window",
        attributes={"service.name": str(service_name), "hitl.required": True},
    ):
        try:
            req = MaintenanceWindowRequest(
                service_name=service_name,
                start_time_utc=start_time_utc,
                duration_minutes=duration_minutes,
                change_summary=get_default_redactor().redact_text(change_summary),
                approval_token=approval_token,
            )
        except ValidationError as exc:
            return _format_validation_error(
                exc,
                tool_name="schedule_maintenance_window",
                recovery_hint=(
                    "Check that `start_time_utc` is ISO-8601 UTC (e.g., '2026-11-21T02:00:00Z'), "
                    "`duration_minutes` is between 15 and 240, and `change_summary` is at least "
                    "10 characters, then retry `schedule_maintenance_window`."
                ),
                allowed_values={"service_name": sorted(SERVICE_TELEMETRY_CATALOG.keys())},
            )

        if req.service_name not in SERVICE_TELEMETRY_CATALOG:
            return ToolErrorResponse(
                error_code="UNKNOWN_SERVICE",
                message=f"Unknown service '{req.service_name}' for maintenance scheduling.",
                invalid_fields=["service_name"],
                recovery_instructions=(
                    "Select a registered service from `allowed_values.service_name` and retry."
                ),
                retryable=True,
                allowed_values={"service_name": sorted(SERVICE_TELEMETRY_CATALOG.keys())},
            ).model_dump(mode="json")

        gate = get_default_hitl_gate()
        approved, approver_id = gate.verify_approval(
            tool_name="schedule_maintenance_window",
            approval_token=req.approval_token,
            tool_context=tool_context,
        )
        if not approved:
            pending = gate.request_approval(
                tool_name="schedule_maintenance_window",
                tool_args=req.model_dump(mode="json"),
                tool_context=tool_context,
            )
            return pending.model_dump(mode="json")

        change_id = f"CHG-{uuid.uuid4().hex[:8].upper()}"
        result = MaintenanceWindowResult(
            change_id=change_id,
            service_name=req.service_name,
            start_time_utc=req.start_time_utc,
            duration_minutes=req.duration_minutes,
            approved_by=approver_id or "verified-human-operator",
            notification_channels=["status-page", "#sre-change-advisory", "enterprise-tam-digest"],
        )
        get_default_knowledge_store().record_audit_action(
            action_id=change_id,
            action_type="maintenance_window",
            service_name=req.service_name,
            payload=result.model_dump(mode="json"),
            approved_by=result.approved_by,
        )
        return result.model_dump(mode="json")


# Explicit ADK FunctionTool wrappers with Pydantic schema bindings & HITL flags.
fetch_service_health_metrics_tool = SchemaValidatedFunctionTool(
    fetch_service_health_metrics,
    input_schema=ServiceHealthQuery,
    output_schema=ServiceHealthResult,
    require_confirmation=False,
)
search_incident_runbooks_tool = SchemaValidatedFunctionTool(
    search_incident_runbooks,
    input_schema=RunbookSearchQuery,
    output_schema=RunbookSearchResult,
    require_confirmation=False,
)
create_critical_incident_ticket_tool = SchemaValidatedFunctionTool(
    create_critical_incident_ticket,
    input_schema=CriticalIncidentRequest,
    output_schema=CriticalIncidentResult,
    require_confirmation=False,
)
execute_production_service_rollback_tool = SchemaValidatedFunctionTool(
    execute_production_service_rollback,
    input_schema=ProductionRollbackRequest,
    output_schema=ProductionRollbackResult,
    require_confirmation=True,
)
schedule_maintenance_window_tool = SchemaValidatedFunctionTool(
    schedule_maintenance_window,
    input_schema=MaintenanceWindowRequest,
    output_schema=MaintenanceWindowResult,
    require_confirmation=True,
)


def get_all_ops_tools() -> list[SchemaValidatedFunctionTool]:
    """Returns all registered Enterprise Ops FunctionTool instances."""
    return [
        fetch_service_health_metrics_tool,
        search_incident_runbooks_tool,
        create_critical_incident_ticket_tool,
        execute_production_service_rollback_tool,
        schedule_maintenance_window_tool,
    ]
